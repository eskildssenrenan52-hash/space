import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Conquista Galáctica — Estratégia Espacial 3D" },
      { name: "description", content: "Simulador de império galáctico em 3D: explore galáxias, construa robôs, gerencie naves e registre a história do universo." },
      { property: "og:title", content: "Conquista Galáctica" },
      { property: "og:description", content: "Simulador de império galáctico em 3D com Linha do Tempo Universal e engenharia de robôs." },
    ],
  }),
  component: Index,
});

function Index() {
  const [Game, setGame] = useState<React.ComponentType | null>(null);
  useEffect(() => {
    // R3F / Three.js are client-only — load after mount to avoid SSR issues.
    let cancelled = false;
    import("../game/GameApp").then((mod) => {
      if (!cancelled) setGame(() => mod.default);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  if (!Game) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-950 text-cyan-300">
        Carregando universo...
      </div>
    );
  }

  return (
    <div className="w-full min-h-screen bg-gray-950">
      <Game />
    </div>
  );
}
