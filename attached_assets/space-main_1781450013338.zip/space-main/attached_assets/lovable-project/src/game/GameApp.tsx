import React, { useEffect, useState } from 'react';
import { GameCanvas3D as GameScene3D, SystemScene, PlanetScene } from './Scene3D';
import ShipInterior3DView from './ShipInterior3D';
import { GameHUD } from './GamePanels';
import { useGameStore } from './gameStore';
import { TimelinePanel } from './TimelinePanel';
import { EngineeringPanel } from './EngineeringPanel';
import { EmpireToolbar, EmpireOverlays } from './EmpirePanels';
import { NotificationToaster } from './ColonyPanels';
import { CityScene } from './CityScene';
import { useEmpireTick } from './useEmpireTick';
import { useT } from './i18n';
import { PilotHUD } from './PilotMode';
import { ColonizationStatusChip } from './ColonizationPanel';
import { CinematicLayer } from './CinematicLayer';
import { CommandPalette } from './CommandPalette';
import { BattleArena3D } from './BattleArena3D';

// Loading screen
const LoadingScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);
  const [text, setText] = useState('Initializing...');

  useEffect(() => {
    const messages = [
      'Generating galaxies...',
      'Creating star systems...',
      'Building planets...',
      'Initializing ships...',
      'Loading 3D models...',
      'Establishing origin world...',
      'Preparing hyperspace routes...',
      'Ready!'
    ];

    let p = 0;
    const interval = setInterval(() => {
      p += 12.5;
      setProgress(Math.min(100, p));
      setText(messages[Math.floor(p / 12.5)] || messages[messages.length - 1]);

      if (p >= 100) {
        clearInterval(interval);
        setTimeout(onComplete, 400);
      }
    }, 200);

    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center z-50 overflow-hidden"
         style={{ background: 'radial-gradient(ellipse at center, oklch(0.12 0.05 265) 0%, oklch(0.04 0.02 270) 70%, #000 100%)' }}>
      {/* Animated star field */}
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 220 }).map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white animate-holo-flicker"
            style={{
              width: Math.random() * 2 + 0.4,
              height: Math.random() * 2 + 0.4,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: Math.random() * 0.6 + 0.2,
              animationDelay: `${Math.random() * 3}s`,
              boxShadow: '0 0 4px white',
            }}
          />
        ))}
      </div>
      {/* Holo grid floor */}
      <div className="holo-grid-bg absolute inset-x-0 bottom-0 h-1/2 opacity-30"
           style={{ maskImage: 'linear-gradient(to top, black, transparent)', WebkitMaskImage: 'linear-gradient(to top, black, transparent)' }} />

      {/* Rotating concentric rings */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="animate-holo-rotate w-[520px] h-[520px] rounded-full border border-[color:var(--color-holo-cyan)]/20" />
        <div className="animate-holo-rotate w-[360px] h-[360px] absolute rounded-full border border-[color:var(--color-holo-violet)]/30" style={{ animationDirection: 'reverse', animationDuration: '14s' }} />
        <div className="animate-holo-rotate w-[240px] h-[240px] absolute rounded-full border border-dashed border-[color:var(--color-holo-cyan)]/40" style={{ animationDuration: '8s' }} />
      </div>

      <div className="relative z-10 text-center px-6">
        <div className="holo-label mb-3 animate-holo-pulse text-[color:var(--color-holo-cyan)]">// system boot · stardate 3287.4</div>
        <h1 className="font-display text-6xl md:text-7xl font-black holo-text mb-3 tracking-widest animate-holo-flicker">
          CONQUISTA GALÁCTICA
        </h1>
        <p className="text-[color:var(--color-holo-cyan)]/70 font-mono-hud text-sm tracking-[0.4em] uppercase mb-10">3D · Space · Strategy</p>

        <div className="relative w-96 max-w-full mx-auto">
          <div className="holo-corners holo-panel rounded-md p-1">
            <div className="h-2.5 rounded-sm overflow-hidden bg-black/40">
              <div className="h-full transition-all duration-200"
                   style={{ width: `${progress}%`, background: 'var(--holo-gradient-primary)', boxShadow: 'var(--holo-glow-cyan)' }} />
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between font-mono-hud text-xs">
            <span className="text-[color:var(--color-holo-cyan)]">{text}</span>
            <span className="text-[color:var(--color-holo-violet)]">{progress.toFixed(0)}%</span>
          </div>
        </div>

        <div className="mt-10 grid grid-cols-2 md:grid-cols-3 gap-2 max-w-xl mx-auto">
          {[
            ['holo-cyan', 'Galáxia 3D real'],
            ['holo-violet', 'Naves interativas'],
            ['holo-blue', 'Interior 3D da nave'],
            ['holo-emerald', 'Árvore de pesquisa'],
            ['holo-amber', 'Gestão de colônias'],
            ['holo-magenta', 'Manutenção tática'],
          ].map(([c, label]) => (
            <div key={label} className="holo-chip animate-holo-pulse" style={{ borderColor: `color-mix(in oklab, var(--color-${c}) 50%, transparent)`, color: `color-mix(in oklab, var(--color-${c}) 90%, white)`, animationDelay: `${Math.random()}s` }}>
              <span className="w-1.5 h-1.5 rounded-full" style={{ background: `var(--color-${c})`, boxShadow: `0 0 8px var(--color-${c})` }} />
              {label}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Main menu
const MainMenu: React.FC<{ onStart: () => void }> = ({ onStart }) => {
  const t = useT();
  return (
    <div className="fixed inset-0 flex items-center justify-center z-40 overflow-hidden"
         style={{ background: 'radial-gradient(ellipse at 50% 40%, oklch(0.14 0.07 270) 0%, oklch(0.05 0.03 270) 65%, #000 100%)' }}>
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 300 }).map((_, i) => {
          const colors = ['#ffffff', '#ff9999', '#99ccff', '#ffff99'];
          return (
            <div
              key={i}
              className="absolute rounded-full animate-holo-flicker"
              style={{
                width: Math.random() * 2 + 0.5,
                height: Math.random() * 2 + 0.5,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                backgroundColor: colors[Math.floor(Math.random() * colors.length)],
                opacity: Math.random() * 0.7 + 0.2,
                animationDelay: `${Math.random() * 4}s`,
                boxShadow: `0 0 6px ${colors[Math.floor(Math.random() * colors.length)]}`,
              }}
            />
          );
        })}
      </div>

      <div className="absolute inset-0 flex items-center justify-center opacity-30 pointer-events-none">
        <div
          className="w-[640px] h-[640px] rounded-full animate-holo-rotate"
          style={{
            background: 'conic-gradient(from 0deg, transparent 0deg, rgba(100,180,255,0.35) 60deg, rgba(170,80,220,0.3) 180deg, transparent 300deg)',
            transform: 'rotateX(60deg)',
            filter: 'blur(40px)',
            animationDuration: '40s',
          }}
        />
      </div>

      <div className="relative z-10 text-center px-6">
        <div className="holo-label mb-3 text-[color:var(--color-holo-cyan)] animate-holo-pulse">// command bridge · ready</div>
        <h1 className="font-display text-6xl md:text-8xl font-black holo-text mb-2 tracking-[0.06em] animate-holo-flicker">
          {t('app.title')}
        </h1>
        <p className="font-mono-hud text-[color:var(--color-holo-cyan)]/70 text-sm tracking-[0.5em] uppercase mb-12">{t('app.subtitle')}</p>

        <div className="flex flex-col items-center gap-3">
          <button onClick={onStart} className="holo-btn holo-corners w-64 text-base">
            ▶ {t('menu.new')}
          </button>
          <button className="holo-btn-ghost w-64">{t('menu.load')}</button>
        </div>

        <div className="mt-14 max-w-3xl mx-auto">
          <div className="grid grid-cols-3 gap-3">
            {[
              ['50+', 'Galaxies',     'holo-cyan'],
              ['3D',  'Ship Interiors','holo-violet'],
              ['20+', 'Room Types',   'holo-blue'],
              ['15+', 'Technologies', 'holo-emerald'],
              ['100s','Resources',    'holo-amber'],
              ['\u221E','Possibilities','holo-magenta'],
            ].map(([val, label, c]) => (
              <div key={label as string} className="holo-panel holo-corners rounded-lg p-3 holo-scanlines">
                <div className="holo-stat-value text-2xl" style={{ color: `var(--color-${c})`, textShadow: `0 0 14px var(--color-${c})` }}>{val}</div>
                <div className="holo-label mt-1">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

// Main game view
const GameView: React.FC = () => {
  const { showShipInterior } = useGameStore();
  useEmpireTick();

  return (
    <div className="relative w-full h-screen overflow-hidden bg-gray-950">
      {/* 3D Scene */}
      <GameScene3D />

      {/* Cinematic ambient layer (above 3D, below HUD) */}
      {!showShipInterior && <CinematicLayer />}

      {/* HUD overlay */}
      <GameHUD />

      {/* 3D Ship Interior overlay */}
      {showShipInterior && <ShipInterior3DView />}

      {/* Linha do Tempo + Engenharia */}
      <TimelinePanel />
      <EngineeringPanel />

      {/* Império: Indústria, Mercado, Construção, Guerra, Missões, Tutorial */}
      <EmpireToolbar />
      <EmpireOverlays />

      {/* Notificações flutuantes + visualização 3D da cidade */}
      <NotificationToaster />
      <CityScene />

      {/* Modo Piloto — WASD/setas para voar com a nave */}
      <PilotHUD />

      {/* Status flutuante das missões de colonização ativas */}
      <ColonizationStatusChip />

      {/* Global Command Palette (Ctrl/Cmd+K) */}
      <CommandPalette />

      {/* 3D Battle Arena replay (replaces legacy 2D replay modal) */}
      <BattleArena3D />
    </div>
  );
};

// Main App
function App() {
  const [state, setState] = useState<'menu' | 'loading' | 'playing'>('menu');

  if (state === 'menu') {
    return <MainMenu onStart={() => setState('loading')} />;
  }

  if (state === 'loading') {
    return <LoadingScreen onComplete={() => setState('playing')} />;
  }

  return <GameView />;
}

export default App;
