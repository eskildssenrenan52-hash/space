# Conquista Galáctica

A massively expanded 3D space strategy game in React+Vite. Command your empire across 50+ galaxies, manage resources, colonize 32 planet biomes, build mega-structures, recruit legendary heroes, manage trade routes, face rival AI empires, and survive galactic events.

## Run & Operate

- `pnpm --filter @workspace/conquista-galactica run dev` — run the game (port 18237)
- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string, `SESSION_SECRET` — session secret

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Game: React + Vite + Three.js (@react-three/fiber + @react-three/drei)
- State: Zustand stores (per-system)
- Styling: Tailwind CSS v4
- Icons: Lucide React
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/conquista-galactica/src/game/` — all game code
- `artifacts/conquista-galactica/src/game/gameStore.ts` — main game state (planets, ships, colonies, resources)
- `artifacts/conquista-galactica/src/game/GameApp.tsx` — root app, tick loop, toolbar, main menu
- `artifacts/conquista-galactica/src/game/Scene3D.tsx` — 3D galaxy/planet rendering
- `artifacts/conquista-galactica/src/game/data/` — data files for wonders, AI empires, events, heroes
- `artifacts/conquista-galactica/src/game/HeroesPanel.tsx` — legendary heroes system
- `artifacts/conquista-galactica/src/game/GalacticWonders.tsx` — mega-structures
- `artifacts/conquista-galactica/src/game/AIEmpiresPanel.tsx` — rival AI empires + diplomacy
- `artifacts/conquista-galactica/src/game/GalacticEventsPanel.tsx` — random galactic events
- `artifacts/conquista-galactica/src/game/TradeRoutesPanel.tsx` — interstellar trade routes
- `artifacts/conquista-galactica/src/types/three.d.ts` — Three.js ambient type declarations

## Architecture decisions

- **Zustand per-system stores**: Each major system (wonders, AI empires, events, trade, heroes) has its own Zustand store co-located with the panel component. Stores are accessed via `.getState()` in the master tick loop to avoid React re-render overhead.
- **Master tick loop in GameApp.tsx**: `useExpandedTick()` hook drives all stores via rAF — delta time capped at 0.1s to prevent physics runaway on tab focus return.
- **Weighted planet generation**: `generatePlanets()` uses a weighted pool so common biomes (terrestrial, ocean, gas_giant) appear 8x more than rare ones (ascended, quantum, void).
- **Three.js types**: `three@0.184.0` doesn't export types via package.json `exports`. Fix is a custom ambient declaration at `src/types/three.d.ts`. Pre-existing TS errors in original files are suppressed by this approach.
- **No routing**: SPA — all game views managed by local state in GameApp.tsx (menu → loading → playing).

## Product

- 50+ galaxies with 3D star fields and planet orbits
- 32 planet biomes (Tier 1: terrestrial→toxic, Tier 2: crystalline→tundra, Tier 3: plasma→pulsed, Tier 4: dyson_shell→ascended)
- 9 galactic wonders (Tier 1-5: Relay Network → Matrioshka Brain)
- 8 rival AI empire templates with full diplomacy (war/hostile/neutral/friendly/allied)
- 11 random galactic event types with player choices
- Interstellar trade routes with passive income and upgrades
- 11 legendary heroes across 8 classes (Admiral, Scientist, Diplomat, Engineer, Spy, Colonist, Warlord, Oracle)
- XP/leveling system (1-20) with unlockable abilities per hero
- 3D ship interiors, city scenes, battle arenas
- Cinematic layer, command palette, full empire management

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Three.js Fast Refresh warnings ("store export incompatible") are cosmetic — cause full page reload instead of HMR but don't break the game. To fix properly, move Zustand stores to separate files.
- `types` array in tsconfig is locked; custom types must go in `src/types/` and use `typeRoots` in tsconfig.
- Do NOT run `pnpm dev` at workspace root — use workflow restart or `pnpm --filter` commands.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
