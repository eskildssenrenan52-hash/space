---
name: Conquista Galáctica architecture
description: Key non-obvious decisions for the space strategy game — stores, tick loop, types, planet gen.
---

## Zustand store co-location
Each system (wonders, AI empires, events, trade, heroes) has its Zustand store defined in the same file as the panel component. Stores are exported alongside panel components. This causes Vite Fast Refresh warnings ("export incompatible") but does NOT break the game — it causes a full page reload instead of HMR, which is acceptable.

**Why:** Avoids creating many separate store files. To fix Fast Refresh properly, move store creation to `<system>Store.ts` files and import from there.

**How to apply:** Any new system should follow the same pattern until user requests the fix.

## Master rAF tick in GameApp.tsx
`useExpandedTick()` in GameApp.tsx drives all stores via `requestAnimationFrame`. Stores are accessed via `.getState()` (not React subscription) to avoid triggering re-renders on every frame.

**Why:** Avoids performance-killing re-renders 60 times/second for game logic.

**How to apply:** Any new store with a `tick(delta)` method should be added to `useExpandedTick()` in GameApp.tsx.

## Three.js types fix
`three@0.184.0` does NOT export types via `package.json` `exports` field. Custom ambient declarations live at `artifacts/conquista-galactica/src/types/three.d.ts`. The tsconfig uses `typeRoots` to include this directory.

**Why:** Without this, all Three.js imports produce TS2307 "module not found" errors even though the code runs fine via Vite's bundler resolution.

## Weighted planet biome generation
`generatePlanets()` builds a weighted pool array where common biomes (terrestrial, ocean, gas_giant = weight 7-8) repeat 7-8 times and rare biomes (ascended, quantum, void = weight 0.1-0.2) appear 1 time. Selection picks randomly from this pool.

**Why:** Naive uniform random selection over 32 biome types would make common biomes appear only ~3% of the time. Weighted pool makes the galaxy feel natural.

## 32 planet biomes
Tier 1 (classic): terrestrial, gas_giant, ice, lava, ocean, desert, frozen, toxic, artificial, living
Tier 2: crystalline, fungal, volcanic_ocean, swamp, paradise, ruins, hollow, storm, jungle, tundra
Tier 3 (exotic): plasma, diamond, shadow, ring_world, gas_dwarf, nebula_world, binary_world, pulsed
Tier 4 (mega-rare): dyson_shell, quantum, void, ascended

## Heroes system
11 hero templates across 8 classes (admiral, scientist, diplomat, engineer, spy, colonist, warlord, oracle). Each hero has: level 1-20, XP accumulation, 5 abilities unlocked at levels 1/5/10/15/20, assignment to fleet or colony, passive XP gain while assigned.

Data lives in `data/heroesData.ts`, store+UI in `HeroesPanel.tsx`. Rarity tiers: common, rare, epic, legendary, mythic.
