// ============================================================================
// COLONY PANELS — city management, mining, component exchange, task center and
// the live notification toaster.
// ============================================================================
import React, { useEffect, useRef, useState } from 'react';
import {
  X, Building2, Pickaxe, ArrowUpCircle, Trash2, Eye, Coins, TrendingUp,
  TrendingDown, ListTodo, Bell, Crown, AlertTriangle, CheckCircle2, Info,
  Zap, Bot,
} from 'lucide-react';
import { useEmpireUI } from './empireUI';
import { useGameStore } from './gameStore';
import { useEmpireStore } from './empireStore';
import {
  useColonyStore, DISTRICTS, DIM_INFO, popCapOf, computeTasks, componentPriceOf,
  type Dimension, type City,
} from './colonyStore';
import { MAT_BY_ID } from './data/industryData';
import { CATALOG_BY_CATEGORY, CATEGORY_LABELS, type CatCategory } from './data/engineeringCatalog';

const Modal: React.FC<{ title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }> = ({ title, onClose, children, wide }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
    <div
      className={`bg-gray-950 border border-cyan-500/40 rounded-2xl shadow-2xl w-full ${wide ? 'max-w-6xl' : 'max-w-4xl'} max-h-[85vh] flex flex-col overflow-hidden`}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="flex items-center justify-between px-5 py-3 border-b border-gray-800 bg-gray-900">
        <h2 className="text-lg font-bold text-cyan-300">{title}</h2>
        <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-800 text-gray-400"><X size={18} /></button>
      </div>
      <div className="flex-1 overflow-y-auto p-5">{children}</div>
    </div>
  </div>
);

const DimBar: React.FC<{ dim: Dimension; value: number }> = ({ dim, value }) => {
  const info = DIM_INFO[dim];
  const low = value < 30;
  return (
    <div>
      <div className="flex items-center justify-between text-[11px] mb-0.5">
        <span className="text-gray-300">{info.icon} {info.name}</span>
        <span className={low ? 'text-red-400 font-bold' : 'text-gray-400'}>{Math.round(value)}</span>
      </div>
      <div className="h-1.5 bg-gray-800 rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all" style={{ width: `${value}%`, backgroundColor: low ? '#ef4444' : info.color }} />
      </div>
    </div>
  );
};

const CityCard: React.FC<{ city: City }> = ({ city }) => {
  const { invest, setViewingCity, setCapital, toggleAutoManage, quickFixCity } = useColonyStore();
  const autoOn = useColonyStore(s => !!s.autoManage[city.id]);
  const inventory = useEmpireStore(s => s.inventory);
  const credits = useGameStore(s => s.credits);
  const cap = popCapOf(city);
  const [open, setOpen] = useState(false);

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-xl p-3">
      <div className="flex items-center gap-2">
        <Building2 size={18} className="text-cyan-400" />
        <div className="flex-1">
          <div className="font-bold text-white text-sm flex items-center gap-1.5">
            {city.name}
            {city.isCapital && <Crown size={13} className="text-amber-400" />}
          </div>
          <div className="text-[11px] text-gray-400">Nível {city.level} · {Math.floor(city.population).toLocaleString()}/{cap.toLocaleString()} hab</div>
        </div>
        <button onClick={() => setViewingCity(city.id)} className="flex items-center gap-1 px-2 py-1 rounded bg-cyan-600/20 text-cyan-300 hover:bg-cyan-600/40 text-xs">
          <Eye size={13} /> Ver 3D
        </button>
      </div>

      {/* Quick action row */}
      <div className="flex items-center gap-1.5 mt-2">
        <button
          onClick={() => quickFixCity(city.id)}
          className="flex-1 flex items-center justify-center gap-1 px-2 py-1 rounded bg-amber-600/20 text-amber-200 hover:bg-amber-600/40 text-[11px] font-semibold"
          title="Constrói automaticamente o distrito mais barato que reforça a dimensão mais fraca."
        >
          <Zap size={12} /> Reforçar agora
        </button>
        <button
          onClick={() => toggleAutoManage(city.id)}
          className={`flex-1 flex items-center justify-center gap-1 px-2 py-1 rounded text-[11px] font-semibold transition-colors ${
            autoOn
              ? 'bg-emerald-600/30 text-emerald-200 hover:bg-emerald-600/50 border border-emerald-500/50'
              : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
          }`}
          title="Quando ligado, a IA do governo investe sozinha sempre que possível."
        >
          <Bot size={12} /> Auto: {autoOn ? 'ON' : 'OFF'}
        </button>
      </div>

      <div className="mt-2">
        <div className="h-1 bg-gray-800 rounded-full overflow-hidden mb-2">
          <div className="h-full bg-purple-500" style={{ width: `${(city.xp / city.xpNext) * 100}%` }} />
        </div>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
          {(['economy', 'energy', 'security', 'ecology', 'health'] as Dimension[]).map(d => (
            <DimBar key={d} dim={d} value={city[d]} />
          ))}
        </div>
      </div>

      <button onClick={() => setOpen(o => !o)} className="w-full mt-2 text-xs text-cyan-300 hover:text-cyan-200">
        {open ? '▲ Ocultar investimentos' : '▼ Investir e expandir cidade'}
      </button>

      {open && (
        <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
          {DISTRICTS.map(d => {
            const canMats = d.materials.every(m => (inventory[m.mat] || 0) >= m.qty);
            const canCred = credits >= d.credits;
            const can = canMats && canCred;
            return (
              <button
                key={d.id}
                disabled={!can}
                onClick={() => invest(city.id, d.id)}
                className={`text-left p-2 rounded-lg border text-[11px] transition-colors ${can ? 'border-gray-700 bg-gray-800 hover:bg-gray-700' : 'border-gray-800 bg-gray-900 opacity-50 cursor-not-allowed'}`}
              >
                <div className="font-semibold text-white flex items-center justify-between">
                  <span>{d.icon} {d.name}</span>
                  <span className="text-amber-300">{d.credits}c</span>
                </div>
                <div className="text-gray-400">{d.desc}</div>
                <div className="text-gray-500 mt-0.5">
                  +{d.support} {DIM_INFO[d.dim].name}{d.popCap ? ` · +${d.popCap.toLocaleString()} hab` : ''}{d.ecoPenalty ? ` · -${d.ecoPenalty} eco` : ''}
                </div>
                <div className="text-gray-500">{d.materials.map(m => `${m.qty}x ${MAT_BY_ID[m.mat]?.namePt || m.mat}`).join(', ')}</div>
              </button>
            );
          })}
        </div>
      )}

      {!city.isCapital && (
        <button onClick={() => setCapital(city.id)} className="w-full mt-2 text-[11px] text-amber-300 hover:text-amber-200">Tornar Capital ⭐</button>
      )}
    </div>
  );
};

const MiningSection: React.FC = () => {
  const planets = useGameStore(s => s.planets);
  const { mines, buildMine, upgradeMine, removeMine } = useColonyStore();
  const ownedPlanets = planets.filter(p => p.owned || p.colonies.length > 0);

  return (
    <div className="space-y-3">
      <h3 className="text-sm font-bold text-amber-300 flex items-center gap-1.5"><Pickaxe size={16} /> Mineração</h3>
      {ownedPlanets.length === 0 && <p className="text-xs text-gray-500">Colonize um planeta para abrir minas em seus depósitos.</p>}
      {ownedPlanets.map(p => (
        <div key={p.id} className="bg-gray-900 border border-gray-800 rounded-lg p-2.5">
          <div className="text-sm font-semibold text-white mb-1.5">{p.name}</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {p.resources.map((dep, i) => (
              <button key={i} onClick={() => buildMine(p.id, i)}
                className="text-left p-2 rounded bg-gray-800 hover:bg-gray-700 text-[11px] flex items-center justify-between">
                <span className="text-gray-200 capitalize">{dep.resource} ({(dep.quality * 100).toFixed(0)}% qual)</span>
                <span className="text-amber-300">⛏️ 800c</span>
              </button>
            ))}
          </div>
        </div>
      ))}

      {mines.length > 0 && (
        <div className="space-y-1.5">
          <h4 className="text-xs font-bold text-gray-300">Minas ativas ({mines.length})</h4>
          {mines.map(m => (
            <div key={m.id} className="flex items-center gap-2 bg-gray-900 border border-gray-800 rounded-lg p-2 text-[11px]">
              <span className="flex-1 text-gray-200">{MAT_BY_ID[m.matId]?.icon} {MAT_BY_ID[m.matId]?.namePt || m.resource} <span className="text-gray-500">@ {m.planetName}</span></span>
              <span className="text-gray-400">Nv {m.upgradeLevel + 1}</span>
              <span className={m.remaining <= 0 ? 'text-red-400' : 'text-gray-500'}>{Math.max(0, Math.floor(m.remaining))} restante</span>
              <button onClick={() => upgradeMine(m.id)} className="text-cyan-400 hover:text-cyan-300"><ArrowUpCircle size={15} /></button>
              <button onClick={() => removeMine(m.id)} className="text-red-400 hover:text-red-300"><Trash2 size={14} /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export const ColonyPanel: React.FC = () => {
  const setPanel = useEmpireUI(s => s.setPanel);
  const citiesMap = useColonyStore(s => s.cities);
  const cities = React.useMemo(() => Object.values(citiesMap), [citiesMap]);
  const lastIncome = useColonyStore(s => s.lastIncome);

  return (
    <Modal title="🏙️ Colônias & Cidades" onClose={() => setPanel(null)} wide>
      <div className="flex items-center gap-3 mb-4 text-xs">
        <span className="flex items-center gap-1 text-amber-300"><Coins size={14} /> Renda das cidades: {lastIncome >= 0 ? <TrendingUp size={13} className="text-green-400" /> : <TrendingDown size={13} className="text-red-400" />} {lastIncome.toFixed(2)}/tick</span>
        <span className="text-gray-500">{cities.length} cidade(s)</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-cyan-300 flex items-center gap-1.5"><Building2 size={16} /> Suas Cidades</h3>
          {cities.length === 0 && (
            <p className="text-xs text-gray-500 bg-gray-900 border border-gray-800 rounded-lg p-3">
              Nenhuma colônia ainda. Vá para a <b className="text-gray-300">vista de Planeta</b>, selecione um mundo habitável e clique em <b className="text-green-300">ESTABLISH COLONY</b>. Depois volte aqui para construir e expandir cidades.
            </p>
          )}
          {cities.map(c => <CityCard key={c.id} city={c} />)}
        </div>
        <MiningSection />
      </div>
    </Modal>
  );
};

// ---------------------------------------------------------------------------
export const ComponentExchange: React.FC = () => {
  const setPanel = useEmpireUI(s => s.setPanel);
  const demand = useColonyStore(s => s.componentDemand);
  const stock = useColonyStore(s => s.componentStock);
  const { buyComponent, sellComponent } = useColonyStore();
  const [cat, setCat] = useState<CatCategory>('weapon');

  const items = (CATALOG_BY_CATEGORY[cat] || []).slice(0, 24);
  const cats = Object.keys(CATEGORY_LABELS).filter(c => c !== 'behavior') as CatCategory[];

  return (
    <Modal title="📈 Bolsa de Componentes (Preço & Demanda)" onClose={() => setPanel(null)} wide>
      <p className="text-xs text-gray-400 mb-3">Os preços flutuam com a demanda do mercado. Compre na baixa, venda na alta para lucrar com a engenharia.</p>
      <div className="flex flex-wrap gap-1.5 mb-3">
        {cats.map(c => {
          const d = demand[c] ?? 1;
          return (
            <button key={c} onClick={() => setCat(c)}
              className={`px-2.5 py-1 rounded text-xs font-semibold ${cat === c ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-300'}`}>
              {CATEGORY_LABELS[c]} <span className={d > 1.2 ? 'text-green-400' : d < 0.8 ? 'text-red-400' : 'text-gray-400'}>{(d).toFixed(2)}x</span>
            </button>
          );
        })}
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
        {items.map(item => {
          const price = componentPriceOf(item, demand);
          const owned = stock[item.id] || 0;
          return (
            <div key={item.id} className="flex items-center gap-2 bg-gray-900 border border-gray-800 rounded-lg p-2 text-[11px]">
              <div className="flex-1">
                <div className="text-gray-200 font-semibold">{item.name}</div>
                <div className="text-gray-500">Tier {item.tier} · você tem {owned}</div>
              </div>
              <span className="text-amber-300 font-bold tabular-nums">{price}c</span>
              <button onClick={() => buyComponent(item.id)} className="px-2 py-1 rounded bg-green-700/40 text-green-200 hover:bg-green-700/60">+</button>
              <button onClick={() => sellComponent(item.id)} disabled={owned <= 0} className="px-2 py-1 rounded bg-red-700/40 text-red-200 hover:bg-red-700/60 disabled:opacity-40">−</button>
            </div>
          );
        })}
      </div>
    </Modal>
  );
};

// ---------------------------------------------------------------------------
export const TaskCenter: React.FC = () => {
  const setPanel = useEmpireUI(s => s.setPanel);
  // re-render periodically so tasks stay fresh
  const [, force] = useState(0);
  useEffect(() => { const i = setInterval(() => force(x => x + 1), 1500); return () => clearInterval(i); }, []);
  const tasks = computeTasks();
  const notifications = useGameStore(s => s.notifications).slice(-12).reverse();

  const pic = (p: string) => p === 'high'
    ? <AlertTriangle size={14} className="text-red-400" />
    : p === 'med' ? <Info size={14} className="text-amber-400" /> : <CheckCircle2 size={14} className="text-gray-400" />;

  return (
    <Modal title="🗒️ Central de Tarefas & Notificações" onClose={() => setPanel(null)}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h3 className="text-sm font-bold text-cyan-300 flex items-center gap-1.5 mb-2"><ListTodo size={16} /> O que fazer agora</h3>
          {tasks.length === 0 && <p className="text-xs text-green-400">Tudo em ordem, Comandante! 🎉</p>}
          <div className="space-y-1.5">
            {tasks.map(t => (
              <button key={t.id} onClick={() => t.panel && setPanel(t.panel as any)}
                className="w-full text-left flex items-start gap-2 bg-gray-900 border border-gray-800 hover:border-cyan-600/50 rounded-lg p-2 text-xs">
                {pic(t.priority)}
                <span className="text-gray-200 flex-1">{t.label}</span>
              </button>
            ))}
          </div>
        </div>
        <div>
          <h3 className="text-sm font-bold text-cyan-300 flex items-center gap-1.5 mb-2"><Bell size={16} /> Histórico</h3>
          <div className="space-y-1">
            {notifications.map(n => (
              <div key={n.id} className={`text-[11px] p-1.5 rounded ${n.type === 'danger' ? 'bg-red-900/30 text-red-200' : n.type === 'warning' ? 'bg-amber-900/30 text-amber-200' : n.type === 'success' ? 'bg-green-900/30 text-green-200' : 'bg-gray-800 text-gray-300'}`}>
                {n.message}
              </div>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
};

// ---------------------------------------------------------------------------
// Floating toaster for new notifications.
export const NotificationToaster: React.FC = () => {
  const notifications = useGameStore(s => s.notifications);
  const [visible, setVisible] = useState<{ id: string; type: string; message: string }[]>([]);
  const seen = useRef<Set<string>>(new Set());

  useEffect(() => {
    const fresh = notifications.filter(n => !seen.current.has(n.id));
    if (fresh.length === 0) return;
    fresh.forEach(n => seen.current.add(n.id));
    setVisible(v => [...v, ...fresh.map(n => ({ id: n.id, type: n.type, message: n.message }))].slice(-4));
    const timers = fresh.map(n => setTimeout(() => {
      setVisible(v => v.filter(x => x.id !== n.id));
    }, 5500));
    return () => timers.forEach(clearTimeout);
  }, [notifications]);

  if (visible.length === 0) return null;
  const cfg = (t: string) => {
    if (t === 'danger')  return { Icon: AlertTriangle, bar: 'from-red-500 to-rose-600',   ring: 'shadow-[0_0_24px_rgba(248,113,113,.35)]', tone: 'bg-red-950/95 border-red-500/50 text-red-100' };
    if (t === 'warning') return { Icon: AlertTriangle, bar: 'from-amber-400 to-orange-500', ring: 'shadow-[0_0_24px_rgba(251,191,36,.35)]', tone: 'bg-amber-950/95 border-amber-500/50 text-amber-100' };
    if (t === 'success') return { Icon: CheckCircle2,  bar: 'from-emerald-400 to-green-500', ring: 'shadow-[0_0_24px_rgba(52,211,153,.35)]', tone: 'bg-emerald-950/95 border-emerald-500/50 text-emerald-100' };
    return                       { Icon: Info,          bar: 'from-cyan-400 to-sky-500',     ring: 'shadow-[0_0_24px_rgba(34,211,238,.35)]', tone: 'bg-gray-900/95 border-cyan-500/50 text-cyan-50' };
  };
  return (
    <div className="fixed top-16 right-4 z-[55] space-y-2 w-80 pointer-events-none">
      {visible.map(n => {
        const c = cfg(n.type);
        return (
          <div key={n.id}
            className={`pointer-events-auto relative rounded-xl pl-3 pr-3 py-2.5 text-xs border backdrop-blur
                        animate-in slide-in-from-right fade-in overflow-hidden ${c.tone} ${c.ring}`}>
            <div className={`absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b ${c.bar}`} />
            <div className="flex items-start gap-2 pl-2">
              <c.Icon size={14} className="mt-0.5 shrink-0 opacity-90" />
              <span className="leading-snug">{n.message}</span>
            </div>
            <div className={`absolute bottom-0 left-0 h-0.5 bg-gradient-to-r ${c.bar}`}
                 style={{ width: '100%', animation: 'shrinkBar 5.5s linear forwards' }} />
          </div>
        );
      })}
      <style>{`@keyframes shrinkBar { from { width: 100%; } to { width: 0%; } }`}</style>
    </div>
  );
};
