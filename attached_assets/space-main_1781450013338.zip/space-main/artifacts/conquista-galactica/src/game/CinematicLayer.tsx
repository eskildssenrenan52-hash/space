// ============================================================================
// CINEMATIC LAYER — full-screen ambient FX (vignette, scanlines, meteors,
// pulsing aurora). Purely additive overlay that sits above the 3D scene but
// below HUD. Pointer-events disabled so nothing is blocked.
// ============================================================================
import React, { useMemo } from 'react';

interface Meteor { left: number; top: number; delay: number; duration: number; size: number; }

export const CinematicLayer: React.FC = () => {
  const meteors = useMemo<Meteor[]>(() => Array.from({ length: 18 }, () => ({
    left: Math.random() * 100,
    top: Math.random() * 60,
    delay: Math.random() * 8,
    duration: 4 + Math.random() * 6,
    size: 80 + Math.random() * 220,
  })), []);

  return (
    <>
      <style>{`
        @keyframes cine-meteor {
          0%   { transform: translate3d(0,0,0) rotate(215deg); opacity: 0; }
          10%  { opacity: 1; }
          100% { transform: translate3d(-900px,900px,0) rotate(215deg); opacity: 0; }
        }
        @keyframes cine-aurora {
          0%,100% { opacity: .35; transform: translate3d(-2%, 0, 0) scale(1); }
          50%     { opacity: .55; transform: translate3d(2%, -1%, 0) scale(1.05); }
        }
        .cine-meteor {
          position: absolute; pointer-events: none;
          height: 1px; border-radius: 999px;
          background: linear-gradient(90deg, rgba(180,230,255,0) 0%, rgba(180,230,255,.9) 60%, #fff 100%);
          box-shadow: 0 0 12px rgba(180,230,255,.9), 0 0 24px rgba(140,200,255,.6);
          animation: cine-meteor linear infinite;
        }
        .cine-scanlines::after {
          content: ''; position: absolute; inset: 0; pointer-events: none;
          background: repeating-linear-gradient(0deg, rgba(255,255,255,0.025) 0px, rgba(255,255,255,0.025) 1px, transparent 1px, transparent 3px);
          mix-blend-mode: overlay; opacity: .35;
        }
        .cine-vignette {
          background: radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,.55) 100%);
        }
        .cine-aurora {
          position: absolute; inset: -10% -5% auto -5%; height: 55%;
          background:
            radial-gradient(60% 80% at 20% 30%, rgba(80,180,255,.18) 0%, transparent 60%),
            radial-gradient(50% 70% at 80% 40%, rgba(180,90,220,.18) 0%, transparent 60%),
            radial-gradient(70% 90% at 50% 20%, rgba(120,255,200,.10) 0%, transparent 60%);
          filter: blur(40px);
          animation: cine-aurora 14s ease-in-out infinite;
        }
      `}</style>
      <div className="pointer-events-none fixed inset-0 z-[15] overflow-hidden cine-scanlines">
        <div className="cine-aurora" />
        {meteors.map((m, i) => (
          <span
            key={i}
            className="cine-meteor"
            style={{
              left: `${m.left}%`,
              top: `${m.top}%`,
              width: `${m.size}px`,
              animationDelay: `${m.delay}s`,
              animationDuration: `${m.duration}s`,
            }}
          />
        ))}
        <div className="cine-vignette absolute inset-0" />
      </div>
    </>
  );
};

export default CinematicLayer;