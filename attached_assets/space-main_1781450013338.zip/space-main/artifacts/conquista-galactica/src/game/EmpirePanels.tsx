import React, { useState } from 'react';
import {
  Factory, ShoppingCart, Hammer, Swords, Target, Cpu, Languages, GraduationCap,
  X, Power, Trash2, Zap, ChevronRight, Star, Eye, Rocket, Play, Plus, Minus, Coins,
  Building2, ListTodo, LineChart,
} from 'lucide-react';
import { useEmpireUI, type PanelId } from './empireUI';
import { useEmpireStore } from './empireStore';
import { useGameStore } from './gameStore';
import { useI18n, useT } from './i18n';
import {
  MACHINES, MACHINE_BY_ID, RECIPES_BY_MACHINE, MAT_BY_ID, MATERIALS, LOGISTICS,
} from './data/industryData';
import {
  BUILDABLES_BY_CATEGORY, BUILD_CATEGORY_LABELS, type BuildCategory, BUILDABLES,
} from './data/buildablesData';
import {
  CATALOG_BY_CATEGORY, CATEGORY_LABELS, CATALOG_PART_COUNT, type CatCategory,
} from './data/engineeringCatalog';
import { ROBOT_BEHAVIORS } from './robotBehaviors';
import {
  RECON_TOOLS, HEROES, ASSAULT_UNITS, computeUnitPower, computeArmyPower, UNIT_BY_ID,
  RARITY_INFO, ROLE_INFO, DAMAGE_INFO, ARMOR_INFO,
} from './data/warData';
import { BATTLE_LAYERS, LAYER_INFO, type BattleLayer } from './data/warData';
import { Troop3DPreview } from './Troop3DPreview';
import { ColonyPanel, ComponentExchange, TaskCenter } from './ColonyPanels';
import { computeTasks } from './colonyStore';
import { ColonizationPanel } from './ColonizationPanel';

// ============================================================================
// Toolbar (bottom-center)
// ============================================================================
export const EmpireToolbar: React.FC = () => {
  const t = useT();
  const { panel, setPanel } = useEmpireUI();
  const { toggleLang, lang } = useI18n();
  const openTutorial = useEmpireStore(s => s.openTutorial);
  const credits = useGameStore(s => s.credits);

  const btns: { id: PanelId; icon: React.ReactNode; label: string; color: string }[] = [
    { id: 'colonies', icon: <Building2 size={16} />, label: t('toolbar.colonies'), color: 'emerald' },
    { id: 'colonization', icon: <Rocket size={16} />, label: 'Colonizar', color: 'cyan' },
    { id: 'industry', icon: <Factory size={16} />, label: t('toolbar.industry'), color: 'amber' },
    { id: 'market', icon: <ShoppingCart size={16} />, label: t('toolbar.market'), color: 'green' },
    { id: 'components', icon: <LineChart size={16} />, label: t('toolbar.components'), color: 'teal' },
    { id: 'build', icon: <Hammer size={16} />, label: t('toolbar.build'), color: 'blue' },
    { id: 'war', icon: <Swords size={16} />, label: t('toolbar.war'), color: 'red' },
    { id: 'missions', icon: <Target size={16} />, label: t('toolbar.missions'), color: 'purple' },
    { id: 'engineering', icon: <Cpu size={16} />, label: t('toolbar.engineering'), color: 'cyan' },
  ];

  const taskCount = computeTasks().filter(x => x.priority === 'high').length;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 flex justify-center pointer-events-none">
      <div className="mb-3 flex items-center gap-1.5 bg-gray-900/95 border border-cyan-500/30 rounded-xl px-2 py-1.5 pointer-events-auto shadow-2xl">
        <div className="flex items-center gap-1 px-2 py-1 mr-1 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
          <Coins size={14} className="text-yellow-400" />
          <span className="text-yellow-300 font-bold text-sm tabular-nums">{Math.floor(credits).toLocaleString()}</span>
        </div>
        {btns.map(b => (
          <button
            key={b.id}
            onClick={() => setPanel(b.id)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors
              ${panel === b.id ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-300 hover:bg-gray-700'}`}
          >
            {b.icon} <span className="hidden sm:inline">{b.label}</span>
          </button>
        ))}
        <div className="w-px h-6 bg-gray-700 mx-1" />
        <button onClick={() => setPanel('tasks')} title={t('toolbar.tasks')}
          className={`relative p-1.5 rounded-lg ${panel === 'tasks' ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-amber-300 hover:bg-gray-700'}`}>
          <ListTodo size={16} />
          {taskCount > 0 && <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center">{taskCount}</span>}
        </button>
        <button onClick={openTutorial} title={t('toolbar.tutorial')} className="p-1.5 rounded-lg bg-gray-800 text-indigo-300 hover:bg-gray-700">
          <GraduationCap size={16} />
        </button>
        <button onClick={toggleLang} title={t('toolbar.lang')} className="flex items-center gap-1 px-2 py-1.5 rounded-lg bg-gray-800 text-gray-300 hover:bg-gray-700 text-xs font-bold">
          <Languages size={14} /> {lang.toUpperCase()}
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// Generic modal shell
// ============================================================================
const Modal: React.FC<{ title: string; onClose: () => void; children: React.ReactNode; wide?: boolean }> = ({ title, onClose, children, wide }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
    <div
      className={`bg-gray-950 border border-cyan-500/40 rounded-2xl shadow-2xl w-full ${wide ? 'max-w-6xl' : 'max-w-4xl'} max-h-[85vh] flex flex-col overflow-hidden`}
      onClick={(e) => e.stopPropagation()}
    >
      <div className="flex items-center justify-between px-5 py-3 border-b border-gray-800 bg-gray-900">
        <h2 className="text-lg font-bold text-cyan-300">{title}</h2>
        <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-800 text-gray-400"><X size={18} /></button>
      </div>
      <div className="flex-1 overflow-y-auto p-5">{children}</div>
    </div>
  </div>
);

const matName = (id: string) => MAT_BY_ID[id]?.namePt || id;
const matIcon = (id: string) => MAT_BY_ID[id]?.icon || '📦';

// ============================================================================
// INDUSTRY PANEL
// ============================================================================
const IndustryPanel: React.FC = () => {
  const t = useT();
  const { setPanel } = useEmpireUI();
  const { factories, inventory, power, buildFactory, setFactoryRecipe, toggleFactory, removeFactory } = useEmpireStore();
  const [tab, setTab] = useState<'chains' | 'factories' | 'logistics'>('factories');
  const [zoom, setZoom] = useState<string | null>(null);

  return (
    <Modal title={`🏭 ${t('industry.title')}`} onClose={() => setPanel(null)} wide>
      {/* power bar */}
      <div className="flex items-center gap-4 mb-4 text-xs">
        <div className="flex items-center gap-1.5 text-green-400"><Zap size={14} /> {t('industry.efficiency')} — Geração: {Math.round(power.generation)}</div>
        <div className={power.demand > power.generation ? 'text-red-400' : 'text-gray-400'}>Demanda: {Math.round(power.demand)}</div>
        <div className="ml-auto flex gap-1">
          {(['factories', 'chains', 'logistics'] as const).map(x => (
            <button key={x} onClick={() => setTab(x)}
              className={`px-3 py-1 rounded text-xs font-semibold ${tab === x ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-400'}`}>
              {x === 'factories' ? t('industry.factories') : x === 'chains' ? t('industry.chains') : t('industry.logistics')}
            </button>
          ))}
        </div>
      </div>

      {tab === 'factories' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* build menu */}
          <div>
            <h3 className="text-sm font-bold text-gray-300 mb-2">{t('industry.machines')}</h3>
            <div className="grid grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1">
              {MACHINES.map(m => (
                <button key={m.id} onClick={() => buildFactory(m.id, 'Terra')}
                  className="text-left p-2 rounded-lg bg-gray-900 border border-gray-800 hover:border-cyan-500/50">
                  <div className="text-lg">{m.icon}</div>
                  <div className="text-xs font-semibold text-white">{m.namePt}</div>
                  <div className="text-[10px] text-gray-500">{m.descPt}</div>
                  <div className="text-[10px] text-yellow-400 mt-1">{m.buildCredits} cr · {m.powerDraw < 0 ? `+${-m.powerDraw}⚡` : `${m.powerDraw}⚡`}</div>
                </button>
              ))}
            </div>
          </div>

          {/* active factories */}
          <div>
            <h3 className="text-sm font-bold text-gray-300 mb-2">{t('industry.factories')} ({factories.length})</h3>
            {factories.length === 0 && <p className="text-xs text-gray-500">{t('industry.empty')}</p>}
            <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
              {factories.map(f => {
                const machine = MACHINE_BY_ID[f.machineId];
                const recipes = RECIPES_BY_MACHINE[f.machineId] || [];
                return (
                  <div key={f.id} className="p-2 rounded-lg bg-gray-900 border border-gray-800">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{machine.icon}</span>
                      <span className="text-xs font-semibold text-white flex-1">{machine.namePt}</span>
                      <button onClick={() => setZoom(zoom === f.id ? null : f.id)} className="p-1 text-cyan-400 hover:bg-gray-800 rounded" title={t('industry.zoom')}><Eye size={14} /></button>
                      <button onClick={() => toggleFactory(f.id)} className={`p-1 rounded ${f.active ? 'text-green-400' : 'text-gray-600'}`}><Power size={14} /></button>
                      <button onClick={() => removeFactory(f.id)} className="p-1 text-red-400 hover:bg-gray-800 rounded"><Trash2 size={14} /></button>
                    </div>
                    <select value={f.recipeId || ''} onChange={(e) => setFactoryRecipe(f.id, e.target.value)}
                      className="w-full mt-1.5 bg-gray-800 text-xs text-gray-200 rounded px-1.5 py-1 border border-gray-700">
                      <option value="">— escolher receita —</option>
                      {recipes.map(r => <option key={r.id} value={r.id}>{r.namePt}</option>)}
                    </select>
                    {f.recipeId && (
                      <div className="mt-1.5">
                        <div className="w-full h-1.5 bg-gray-800 rounded-full overflow-hidden">
                          <div className="h-full bg-cyan-500 transition-all" style={{ width: `${f.progress * 100}%` }} />
                        </div>
                        <div className="flex justify-between text-[10px] text-gray-500 mt-0.5">
                          <span>Ciclos: {f.cyclesDone}</span>
                          <span className={f.efficiency > 0.9 ? 'text-green-400' : f.efficiency > 0.5 ? 'text-yellow-400' : 'text-red-400'}>
                            {t('industry.efficiency')}: {Math.round(f.efficiency * 100)}%
                          </span>
                        </div>
                      </div>
                    )}
                    {zoom === f.id && (
                      <div className="mt-2 p-2 rounded bg-black/40 border border-cyan-500/20 text-[10px] text-cyan-200">
                        <div className="animate-pulse">🔧 {machine.namePt} operando... veículos circulando, robôs transportando cargas, recursos sendo processados.</div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {tab === 'chains' && (
        <div>
          <p className="text-xs text-gray-400 mb-3">Cada item possui peso, volume, qualidade e pureza. A cadeia vai de minério bruto até megaestruturas.</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {MATERIALS.map(m => (
              <div key={m.id} className="p-2 rounded-lg bg-gray-900 border border-gray-800">
                <div className="flex items-center gap-1.5">
                  <span>{m.icon}</span>
                  <span className="text-xs font-semibold text-white">{m.namePt}</span>
                  <span className="ml-auto text-[10px] px-1 rounded bg-gray-800 text-cyan-300">T{m.tier}</span>
                </div>
                <div className="grid grid-cols-2 gap-x-2 mt-1 text-[10px] text-gray-500">
                  <span>{t('industry.weight')}: {m.weight}kg</span>
                  <span>{t('industry.volume')}: {m.volume}m³</span>
                  <span>{t('industry.quality')}: {Math.round(m.baseQuality * 100)}%</span>
                  <span>{t('industry.purity')}: {Math.round(m.basePurity * 100)}%</span>
                </div>
                <div className="text-[10px] text-amber-400 mt-1">Estoque: {Math.floor(inventory[m.id] || 0)}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'logistics' && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {LOGISTICS.map(l => (
            <div key={l.id} className="p-2.5 rounded-lg bg-gray-900 border border-gray-800">
              <div className="flex items-center gap-1.5"><span className="text-lg">{l.icon}</span><span className="text-xs font-semibold text-white">{l.namePt}</span></div>
              <div className="text-[10px] text-gray-500 mt-1">{l.descPt}</div>
              <div className="flex justify-between text-[10px] mt-1.5">
                <span className="text-cyan-300">{l.throughput} un/s · {l.range}</span>
                <span className="text-yellow-400">{l.costCredits} cr</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </Modal>
  );
};

// ============================================================================
// MARKET PANEL
// ============================================================================
const MarketPanel: React.FC = () => {
  const t = useT();
  const { setPanel } = useEmpireUI();
  const { npcListings, buyListing, inventory, sellMaterial, refreshMarket } = useEmpireStore();
  const robots = useGameStore(s => s.robots);
  const listRobotOnMarket = useGameStore(s => s.listRobotOnMarket);
  const [tab, setTab] = useState<'buy' | 'sell'>('buy');
  const [sellQty, setSellQty] = useState<Record<string, number>>({});

  return (
    <Modal title={`🛒 ${t('market.title')}`} onClose={() => setPanel(null)} wide>
      <div className="flex gap-1 mb-4">
        {(['buy', 'sell'] as const).map(x => (
          <button key={x} onClick={() => setTab(x)}
            className={`px-3 py-1 rounded text-xs font-semibold ${tab === x ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-400'}`}>
            {x === 'buy' ? t('market.buy_tab') : t('market.sell_tab')}
          </button>
        ))}
        <button onClick={refreshMarket} className="ml-auto px-3 py-1 rounded text-xs bg-gray-800 text-gray-300 hover:bg-gray-700">↻ Atualizar</button>
      </div>

      {tab === 'buy' && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {npcListings.map(l => (
            <div key={l.id} className="p-3 rounded-lg bg-gray-900 border border-gray-800">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-800 text-cyan-300">
                  {l.kind === 'robot' ? t('market.robots') : l.kind === 'resource' ? t('market.resources') : t('market.blueprints')}
                </span>
              </div>
              <div className="text-sm font-semibold text-white mt-1">{l.name}</div>
              {l.stats && <div className="text-[10px] text-gray-500 mt-0.5">{l.stats}</div>}
              <div className="text-[10px] text-gray-500 mt-0.5">{t('market.seller')}: {l.seller}</div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-yellow-400 text-xs font-bold">{l.price} cr {l.qty > 1 && `· ${l.qty}x`}</span>
                <button onClick={() => buyListing(l.id)} className="px-2.5 py-1 rounded bg-green-600 hover:bg-green-500 text-white text-xs font-bold">{t('common.buy')}</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'sell' && (
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-bold text-gray-300 mb-2">{t('market.resources')}</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {MATERIALS.filter(m => (inventory[m.id] || 0) > 0).map(m => (
                <div key={m.id} className="p-2 rounded-lg bg-gray-900 border border-gray-800">
                  <div className="text-xs font-semibold text-white">{m.icon} {m.namePt}</div>
                  <div className="text-[10px] text-gray-500">Estoque: {Math.floor(inventory[m.id] || 0)}</div>
                  <div className="flex items-center gap-1 mt-1.5">
                    <input type="number" min={1} max={Math.floor(inventory[m.id] || 0)} value={sellQty[m.id] || 1}
                      onChange={(e) => setSellQty(s => ({ ...s, [m.id]: Math.max(1, +e.target.value) }))}
                      className="w-14 bg-gray-800 text-xs text-white rounded px-1 py-0.5 border border-gray-700" />
                    <button onClick={() => sellMaterial(m.id, Math.min(sellQty[m.id] || 1, Math.floor(inventory[m.id] || 0)))}
                      className="flex-1 px-2 py-0.5 rounded bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold">{t('common.sell')}</button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-300 mb-2">{t('market.robots')} ({robots.length})</h3>
            {robots.length === 0 && <p className="text-xs text-gray-500">Projete robôs na Engenharia para vendê-los aqui.</p>}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {robots.map(r => (
                <div key={r.id} className="p-2 rounded-lg bg-gray-900 border border-gray-800">
                  <div className="text-xs font-semibold text-white">🤖 {r.name}</div>
                  <div className="text-[10px] text-gray-500">{r.chassis} · {r.program.length} comportamentos</div>
                  {r.forSale ? <div className="text-[10px] text-green-400 mt-1">À venda por {r.price} cr</div> : (
                    <button onClick={() => listRobotOnMarket(r.id, 1000 + r.program.length * 100 + r.armor * 20)}
                      className="w-full mt-1.5 px-2 py-0.5 rounded bg-green-600 hover:bg-green-500 text-white text-xs font-bold">{t('market.list')}</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </Modal>
  );
};

// ============================================================================
// BUILD PANEL (planetary construction)
// ============================================================================
const BuildPanel: React.FC = () => {
  const t = useT();
  const { setPanel } = useEmpireUI();
  const { queueBuild, buildQueue, builtUnits, inventory } = useEmpireStore();
  const [cat, setCat] = useState<BuildCategory>('satellite');
  const cats = Object.keys(BUILD_CATEGORY_LABELS) as BuildCategory[];

  return (
    <Modal title={`🔨 ${t('build.title')}`} onClose={() => setPanel(null)} wide>
      <div className="flex flex-wrap gap-1 mb-4">
        {cats.map(c => (
          <button key={c} onClick={() => setCat(c)}
            className={`px-2.5 py-1 rounded text-xs font-semibold ${cat === c ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-400'}`}>
            {BUILD_CATEGORY_LABELS[c]}
          </button>
        ))}
      </div>

      {buildQueue.length > 0 && (
        <div className="mb-4 p-2 rounded-lg bg-gray-900 border border-gray-800">
          <div className="text-xs font-bold text-gray-300 mb-1">{t('build.queue')}</div>
          {buildQueue.map(j => {
            const b = BUILDABLES.find(x => x.id === j.buildableId);
            return (
              <div key={j.id} className="flex items-center gap-2 text-[10px] text-gray-400 mb-1">
                <span className="w-40 truncate">{b?.icon} {b?.name}</span>
                <div className="flex-1 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500" style={{ width: `${j.progress * 100}%` }} />
                </div>
                <span>{Math.round(j.progress * 100)}%</span>
              </div>
            );
          })}
        </div>
      )}

      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {BUILDABLES_BY_CATEGORY[cat].map(b => {
          const owned = builtUnits[b.id] || 0;
          const hasMats = b.materials.every(m => (inventory[m.mat] || 0) >= m.qty);
          return (
            <div key={b.id} className="p-3 rounded-lg bg-gray-900 border border-gray-800">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{b.icon}</span>
                <div>
                  <div className="text-xs font-semibold text-white">{b.name}</div>
                  {owned > 0 && <div className="text-[10px] text-green-400">Possui: {owned}</div>}
                </div>
              </div>
              <div className="text-[10px] text-gray-500 mt-1">{b.desc}</div>
              <div className="text-[10px] text-gray-400 mt-1">
                {b.materials.map(m => (
                  <span key={m.mat} className={(inventory[m.mat] || 0) >= m.qty ? 'text-gray-400' : 'text-red-400'}>
                    {matIcon(m.mat)}{m.qty} </span>
                ))}
              </div>
              <div className="flex items-center justify-between mt-2">
                <span className="text-yellow-400 text-xs font-bold">{b.credits} cr</span>
                <button disabled={!hasMats} onClick={() => queueBuild(b.id, 'Terra')}
                  className={`px-2.5 py-1 rounded text-xs font-bold ${hasMats ? 'bg-blue-600 hover:bg-blue-500 text-white' : 'bg-gray-800 text-gray-600 cursor-not-allowed'}`}>
                  {t('common.build')}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </Modal>
  );
};

// ============================================================================
// ENGINEERING CATALOG PANEL (1000+ components)
// ============================================================================
const EngineeringCatalogPanel: React.FC = () => {
  const t = useT();
  const { setPanel } = useEmpireUI();
  const [cat, setCat] = useState<CatCategory>('chassis');
  const [q, setQ] = useState('');
  const cats = Object.keys(CATEGORY_LABELS) as CatCategory[];
  const totalOptions = CATALOG_PART_COUNT + ROBOT_BEHAVIORS.length;

  const items = cat === 'behavior'
    ? ROBOT_BEHAVIORS.filter(b => b.label.toLowerCase().includes(q.toLowerCase())).map(b => ({
        id: b.id, name: b.label, category: 'behavior' as CatCategory, tier: 1, cost: 0,
        stats: { power: b.energyCost } as Record<string, number>, desc: `Categoria: ${b.category}`,
      }))
    : (CATALOG_BY_CATEGORY[cat] || []).filter(i => i.name.toLowerCase().includes(q.toLowerCase()));

  return (
    <Modal title={`🧠 ${t('eng.catalog')} — ${totalOptions}+ opções`} onClose={() => setPanel(null)} wide>
      <p className="text-xs text-gray-400 mb-3">
        Combine chassis, locomoção, energia, sensores, armas, defesa, manipuladores, comunicação, IA, blindagem e {ROBOT_BEHAVIORS.length} comportamentos
        para criar robôs únicos. Programe-os na bancada de blocos (botão Engenharia no topo) e venda no Mercado.
      </p>
      <div className="flex flex-wrap gap-1 mb-3">
        {cats.map(c => (
          <button key={c} onClick={() => setCat(c)}
            className={`px-2.5 py-1 rounded text-xs font-semibold ${cat === c ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-400'}`}>
            {CATEGORY_LABELS[c]}
          </button>
        ))}
      </div>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('common.search')}
        className="w-full mb-3 bg-gray-900 border border-gray-800 rounded px-3 py-1.5 text-xs text-white" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 max-h-[55vh] overflow-y-auto pr-1">
        {items.slice(0, 300).map(i => (
          <div key={i.id} className="p-2 rounded-lg bg-gray-900 border border-gray-800">
            <div className="text-xs font-semibold text-white leading-tight">{i.name}</div>
            <div className="text-[10px] text-gray-500 mt-0.5">{i.desc}</div>
            <div className="flex flex-wrap gap-1 mt-1">
              {Object.entries(i.stats).map(([k, v]) => (
                <span key={k} className="text-[9px] px-1 rounded bg-gray-800 text-cyan-300">{k}: {v}</span>
              ))}
            </div>
            {i.cost > 0 && <div className="text-[10px] text-yellow-400 mt-1">{i.cost} cr · T{i.tier}</div>}
          </div>
        ))}
      </div>
      <p className="text-[10px] text-gray-600 mt-2">Mostrando {Math.min(300, items.length)} de {items.length} nesta categoria.</p>
    </Modal>
  );
};

// ============================================================================
// MISSIONS PANEL
// ============================================================================
const MissionsPanel: React.FC = () => {
  const t = useT();
  const { setPanel } = useEmpireUI();
  const { missions, claimMission } = useEmpireStore();
  const active = missions.filter(m => !m.claimed);
  const done = missions.filter(m => m.claimed);

  return (
    <Modal title={`🎯 ${t('missions.title')}`} onClose={() => setPanel(null)}>
      <h3 className="text-sm font-bold text-gray-300 mb-2">{t('missions.active')} ({active.length})</h3>
      <div className="space-y-2">
        {active.map(m => {
          const allDone = m.objectives.every(o => o.done);
          return (
            <div key={m.id} className="p-3 rounded-lg bg-gray-900 border border-gray-800">
              <div className="flex items-center justify-between">
                <div className="text-sm font-bold text-white">{m.title}</div>
                <span className="text-xs text-yellow-400">+{m.rewardCredits} cr</span>
              </div>
              <div className="text-xs text-gray-400 mt-0.5">{m.desc}</div>
              <div className="mt-1.5 space-y-1">
                {m.objectives.map((o, i) => (
                  <div key={i} className={`flex items-center gap-1.5 text-xs ${o.done ? 'text-green-400' : 'text-gray-400'}`}>
                    <span>{o.done ? '✅' : '⬜'}</span> {o.label}
                  </div>
                ))}
              </div>
              <button disabled={!allDone} onClick={() => claimMission(m.id)}
                className={`mt-2 px-3 py-1 rounded text-xs font-bold ${allDone ? 'bg-green-600 hover:bg-green-500 text-white' : 'bg-gray-800 text-gray-600'}`}>
                {t('missions.claim')}
              </button>
            </div>
          );
        })}
      </div>
      {done.length > 0 && (
        <>
          <h3 className="text-sm font-bold text-gray-300 mt-4 mb-2">{t('missions.done')} ({done.length})</h3>
          <div className="space-y-1">
            {done.map(m => <div key={m.id} className="text-xs text-gray-500">✅ {m.title}</div>)}
          </div>
        </>
      )}
    </Modal>
  );
};

// ============================================================================
// WAR PANEL
// ============================================================================
const WarPanel: React.FC = () => {
  const t = useT();
  const { setPanel } = useEmpireUI();
  const s = useEmpireStore();
  const [tab, setTab] = useState<'targets' | 'barracks' | 'plan' | 'replays' | 'alliance'>('targets');
  const target = s.targets.find(x => x.id === s.selectedTargetId);

  const TAB_LABELS: Record<typeof tab, string> = {
    targets: t('war.targets'),
    barracks: '🏛️ Quartel',
    plan: t('war.plan'),
    replays: t('war.replays'),
    alliance: t('war.alliance'),
  };

  return (
    <Modal title={`⚔️ ${t('war.title')}`} onClose={() => setPanel(null)} wide>
      <div className="flex gap-1 mb-4 flex-wrap">
        {(['targets', 'barracks', 'plan', 'replays', 'alliance'] as const).map(x => (
          <button key={x} onClick={() => setTab(x)} disabled={x === 'plan' && !target}
            className={`px-3 py-1 rounded text-xs font-semibold ${tab === x ? 'bg-red-600 text-white' : 'bg-gray-800 text-gray-400'} ${x === 'plan' && !target ? 'opacity-40' : ''}`}>
            {TAB_LABELS[x]}
          </button>
        ))}
      </div>

      {tab === 'barracks' && <BarracksTab />}


      {tab === 'targets' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {s.targets.map(tg => (
            <div key={tg.id} className={`p-3 rounded-lg border ${s.selectedTargetId === tg.id ? 'border-red-500 bg-red-950/20' : 'border-gray-800 bg-gray-900'}`}>
              <div className="flex items-center justify-between">
                <div className="text-sm font-bold text-white">{tg.name}</div>
                <div className="flex gap-0.5">
                  {[1, 2, 3].map(i => <Star key={i} size={14} className={i <= tg.starsEarned ? 'text-yellow-400 fill-yellow-400' : 'text-gray-700'} />)}
                </div>
              </div>
              <div className="flex gap-3 text-[10px] text-gray-400 mt-1">
                <span>Dificuldade: {tg.difficulty}/10</span>
                <span>{t('war.intel')}: {tg.intel}%</span>
                <span className="text-yellow-400">Saque: {tg.loot} cr</span>
              </div>
              {/* recon */}
              <div className="mt-2">
                <div className="text-[10px] text-gray-500 mb-1">{t('war.recon')}:</div>
                <div className="flex flex-wrap gap-1">
                  {RECON_TOOLS.map(rt => (
                    <button key={rt.id} onClick={() => { s.selectTarget(tg.id); s.runRecon(rt.id); }}
                      title={`${rt.desc} (${rt.cost} cr)`}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-gray-800 hover:bg-gray-700 text-gray-300">{rt.icon} {rt.name}</button>
                  ))}
                </div>
              </div>
              {/* intel map */}
              {tg.intel > 0 && (
                <div className="mt-2 relative h-32 bg-black/40 rounded border border-gray-800 overflow-hidden">
                  {tg.layout.map(d => {
                    const revealed = (d.id.charCodeAt(d.id.length - 1) % 100) < tg.intel;
                    return (
                      <div key={d.id} title={revealed ? `${d.name} — ${d.effect}` : 'Desconhecido'}
                        className={`absolute -translate-x-1/2 -translate-y-1/2 text-xs ${d.destroyed ? 'opacity-20 grayscale' : ''}`}
                        style={{ left: `${d.x}%`, top: `${d.y}%` }}>
                        {revealed ? d.icon : '❓'}
                      </div>
                    );
                  })}
                </div>
              )}
              <div className="flex gap-2 mt-2">
                <button onClick={() => { s.selectTarget(tg.id); setTab('plan'); }}
                  className="flex-1 px-2 py-1 rounded bg-red-600 hover:bg-red-500 text-white text-xs font-bold flex items-center justify-center gap-1">
                  {t('war.plan')} <ChevronRight size={12} />
                </button>
                <button onClick={() => s.startBlockade(tg.name)} title="Bloqueio econômico (1500 cr)"
                  className="px-2 py-1 rounded bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs">{t('war.blockade')}</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'plan' && target && <WarPlan target={target} />}

      {tab === 'replays' && (
        <div className="space-y-2">
          {s.replays.length === 0 && <p className="text-xs text-gray-500">Nenhum replay ainda. Lance uma invasão!</p>}
          {s.replays.map(r => (
            <button key={r.id} onClick={() => useEmpireStore.setState({ currentReplay: r })}
              className="w-full text-left p-3 rounded-lg bg-gray-900 border border-gray-800 hover:border-cyan-500/40">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-white">{r.targetName}</span>
                <div className="flex gap-0.5">{[1, 2, 3].map(i => <Star key={i} size={12} className={i <= r.stars ? 'text-yellow-400 fill-yellow-400' : 'text-gray-700'} />)}</div>
              </div>
              <div className="text-[10px] text-gray-400 mt-0.5">{r.outcome} · saque {r.lootGained} cr · {r.frames.length} eventos</div>
            </button>
          ))}
        </div>
      )}

      {tab === 'alliance' && (
        <div className="text-sm text-gray-300 space-y-3">
          <p className="text-xs text-gray-400">Coordene invasões em larga escala contra sistemas estelares inteiros. Logística e produção tornam-se tão vitais quanto as batalhas.</p>
          <button onClick={s.toggleAllianceWar}
            className={`px-4 py-2 rounded-lg text-sm font-bold ${s.allianceWarActive ? 'bg-green-600 text-white' : 'bg-gray-800 text-gray-300'}`}>
            {s.allianceWarActive ? '🟢 Guerra de Alianças ATIVA' : 'Iniciar Guerra de Alianças'}
          </button>
          {s.allianceWarActive && (
            <div className="p-3 rounded-lg bg-gray-900 border border-gray-800 text-xs text-gray-400">
              <div className="font-bold text-white mb-1">Frente Coordenada</div>
              <div>• 142 jogadores aliados mobilizados</div>
              <div>• 6 sistemas estelares sob cerco</div>
              <div>• Reforços e cargueiros em trânsito</div>
            </div>
          )}
          {s.blockades.length > 0 && (
            <div>
              <div className="text-xs font-bold text-gray-300 mt-2 mb-1">Bloqueios Ativos</div>
              {s.blockades.map(b => <div key={b.id} className="text-xs text-gray-400">🚫 {b.targetName} — {b.turnsLeft} turnos restantes</div>)}
            </div>
          )}
        </div>
      )}
    </Modal>
  );
};

// ============================================================================
// BARRACKS TAB — recruit, view stockpile, 3D previews, power comparison
// ============================================================================
const RARITY_GRADIENT: Record<string, string> = {
  common:    'from-slate-700/40 to-slate-900/80',
  rare:      'from-sky-600/40 to-slate-900/80',
  epic:      'from-fuchsia-600/40 to-slate-900/80',
  legendary: 'from-amber-500/50 to-orange-900/80',
};

const BarracksTab: React.FC = () => {
  const s = useEmpireStore();
  const credits = useGameStore(s2 => s2.credits);
  const [filter, setFilter] = useState<'all' | BattleLayer>('all');
  const [selected, setSelected] = useState<string | null>(null);
  const [qty, setQty] = useState(1);

  const units = ASSAULT_UNITS.filter(u => filter === 'all' || u.layer === filter);
  const selectedUnit = selected ? UNIT_BY_ID[selected] : units[0];

  const totalArmyPower = Object.entries(s.barracks.troops).reduce(
    (sum, [uid, c]) => sum + (UNIT_BY_ID[uid] ? computeUnitPower(UNIT_BY_ID[uid]) * c : 0), 0,
  );
  const totalUnits = Object.values(s.barracks.troops).reduce((a, b) => a + b, 0);
  const upgradeCost = 2500 * s.barracks.level;

  return (
    <div className="space-y-4">
      {/* Barracks summary bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <SummaryStat label="Nível Quartel" value={`Nv ${s.barracks.level}/5`} accent="text-cyan-300" />
        <SummaryStat label="Poder Militar" value={totalArmyPower.toLocaleString()} accent="text-amber-300" />
        <SummaryStat label="Tropas Estocadas" value={totalUnits.toString()} accent="text-emerald-300" />
        <button onClick={s.upgradeBarracks} disabled={s.barracks.level >= 5}
          className="rounded-lg bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:opacity-40 px-3 py-2 text-xs font-bold text-white">
          ⬆ Upgrade ({upgradeCost.toLocaleString()}cr)
        </button>
      </div>

      {/* Training queue */}
      {s.barracks.queue.length > 0 && (
        <div className="rounded-lg border border-cyan-500/30 bg-cyan-500/5 p-2.5">
          <div className="text-[11px] font-bold text-cyan-300 mb-1.5">⏳ Em treinamento</div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5">
            {s.barracks.queue.map(j => {
              const u = UNIT_BY_ID[j.unitId];
              if (!u) return null;
              return (
                <div key={j.id} className="flex items-center gap-2 text-xs bg-gray-900/60 rounded px-2 py-1.5">
                  <span>{u.icon}</span>
                  <span className="flex-1 text-gray-200">{j.remaining}x {u.name}</span>
                  <div className="w-16 h-1.5 bg-gray-800 rounded-full overflow-hidden">
                    <div className="h-full bg-cyan-400" style={{ width: `${j.progress * 100}%` }} />
                  </div>
                  <button onClick={() => s.cancelTraining(j.id)} className="text-[10px] text-red-400 hover:underline">cancelar</button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        {/* Filter + roster (2 cols) */}
        <div className="lg:col-span-2 space-y-2">
          <div className="flex gap-1.5 flex-wrap">
            <FilterBtn active={filter === 'all'} onClick={() => setFilter('all')}>Todas</FilterBtn>
            {BATTLE_LAYERS.map(l => (
              <FilterBtn key={l} active={filter === l} onClick={() => setFilter(l)}>
                {LAYER_INFO[l].icon} {LAYER_INFO[l].name}
              </FilterBtn>
            ))}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-[480px] overflow-y-auto pr-1">
            {units.map(u => {
              const power = computeUnitPower(u);
              const owned = s.barracks.troops[u.id] || 0;
              const isSelected = selectedUnit?.id === u.id;
              const rarity = RARITY_INFO[u.rarity];
              return (
                <button key={u.id} onClick={() => setSelected(u.id)}
                  className={`text-left rounded-xl border bg-gradient-to-br ${RARITY_GRADIENT[u.rarity]} p-0 overflow-hidden transition
                    ${isSelected ? `border-cyan-400 ring-2 ${rarity.ring} shadow-lg ${rarity.glow}` : 'border-gray-800 hover:border-gray-600'}`}>
                  <div className="h-28 relative">
                    <Troop3DPreview unit={u} compact />
                    <div className={`absolute top-1 left-1 px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wide bg-black/60 ${rarity.color}`}>
                      T{u.tier} · {rarity.label}
                    </div>
                    <div className="absolute top-1 right-1 px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/90 text-amber-950">
                      ⚡{power}
                    </div>
                    {owned > 0 && (
                      <div className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-500/90 text-emerald-950">
                        ×{owned}
                      </div>
                    )}
                  </div>
                  <div className="px-2 py-1.5">
                    <div className="text-[12px] font-bold text-white truncate">{u.icon} {u.name}</div>
                    <div className="flex items-center gap-1 text-[10px] text-gray-400 mt-0.5">
                      <span>{ROLE_INFO[u.role].icon} {ROLE_INFO[u.role].label}</span>
                      <span className="text-gray-600">·</span>
                      <span>{LAYER_INFO[u.layer].icon}</span>
                      <span className="ml-auto text-amber-300 font-semibold">{u.cost}cr</span>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Detail panel + recruit */}
        <div className="rounded-xl bg-gray-950/80 border border-gray-800 p-3">
          {selectedUnit ? (
            <>
              <div className="h-44 rounded-lg overflow-hidden mb-2 border border-gray-800">
                <Troop3DPreview unit={selectedUnit} interactive />
              </div>
              <div className="flex items-start justify-between mb-1">
                <div>
                  <div className={`text-[10px] font-bold uppercase ${RARITY_INFO[selectedUnit.rarity].color}`}>
                    {RARITY_INFO[selectedUnit.rarity].label} · Tier {selectedUnit.tier} · {ROLE_INFO[selectedUnit.role].label}
                  </div>
                  <div className="text-sm font-bold text-white">{selectedUnit.icon} {selectedUnit.name}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-gray-500">Poder</div>
                  <div className="text-base font-black text-amber-300">⚡{computeUnitPower(selectedUnit)}</div>
                </div>
              </div>
              <p className="text-[11px] text-gray-400 leading-snug mb-2">{selectedUnit.desc}</p>

              {/* stat bars */}
              <div className="space-y-1 mb-2">
                <StatBar label="Ataque" value={selectedUnit.attack} max={160} color="bg-red-500" />
                <StatBar label="HP" value={selectedUnit.hp} max={800} color="bg-emerald-500" />
                <StatBar label="Velocidade" value={selectedUnit.speed} max={10} color="bg-sky-500" />
                <StatBar label="Alcance" value={selectedUnit.range} max={10} color="bg-violet-500" />
              </div>

              <div className="grid grid-cols-2 gap-1.5 mb-2 text-[10px]">
                <Pill label="Dano" value={DAMAGE_INFO[selectedUnit.damageType].label} color={DAMAGE_INFO[selectedUnit.damageType].color} />
                <Pill label="Armadura" value={ARMOR_INFO[selectedUnit.armor].label} color={ARMOR_INFO[selectedUnit.armor].color} />
              </div>

              {selectedUnit.abilities.length > 0 && (
                <div className="mb-2">
                  <div className="text-[10px] font-bold text-cyan-300 mb-1">Habilidades</div>
                  {selectedUnit.abilities.map(a => (
                    <div key={a.id} className="text-[10px] text-gray-300 bg-gray-900/60 rounded px-1.5 py-1 mb-0.5">
                      <span className="font-bold text-cyan-200">{a.name}:</span> {a.desc}
                    </div>
                  ))}
                </div>
              )}

              {/* recruit controls */}
              <div className="border-t border-gray-800 pt-2 mt-2">
                <div className="flex items-center gap-1 mb-1.5">
                  <button onClick={() => setQty(Math.max(1, qty - 1))} className="p-1 bg-gray-800 rounded"><Minus size={12} /></button>
                  <input type="number" value={qty} min={1} onChange={(e) => setQty(Math.max(1, +e.target.value || 1))}
                    className="flex-1 bg-gray-900 border border-gray-700 rounded px-2 py-1 text-sm text-center text-white" />
                  <button onClick={() => setQty(qty + 1)} className="p-1 bg-gray-800 rounded"><Plus size={12} /></button>
                  {[5, 10, 25].map(n => (
                    <button key={n} onClick={() => setQty(n)} className="px-1.5 py-0.5 text-[10px] bg-gray-800 rounded text-gray-400 hover:bg-gray-700">{n}</button>
                  ))}
                </div>
                <div className="flex items-center justify-between text-[11px] mb-1.5">
                  <span className="text-gray-400">Custo: <span className="text-amber-300 font-bold">{(selectedUnit.cost * qty).toLocaleString()}cr</span></span>
                  <span className="text-gray-400">Tempo: <span className="text-cyan-300 font-bold">{Math.ceil((selectedUnit.trainTime * qty) / (1 + (s.barracks.level - 1) * 0.4))}s</span></span>
                </div>
                <button onClick={() => s.trainTroop(selectedUnit.id, qty)}
                  disabled={credits < selectedUnit.cost * qty}
                  className="w-full py-2 rounded-lg bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 disabled:opacity-40 text-white text-xs font-bold flex items-center justify-center gap-1.5">
                  <Plus size={14} /> Treinar {qty}x
                </button>
              </div>
            </>
          ) : <p className="text-xs text-gray-500">Selecione uma unidade.</p>}
        </div>
      </div>
    </div>
  );
};

const SummaryStat: React.FC<{ label: string; value: string; accent: string }> = ({ label, value, accent }) => (
  <div className="rounded-lg bg-gray-900/80 border border-gray-800 px-3 py-2">
    <div className="text-[10px] text-gray-500 uppercase">{label}</div>
    <div className={`text-sm font-bold ${accent} tabular-nums`}>{value}</div>
  </div>
);

const FilterBtn: React.FC<{ active: boolean; onClick: () => void; children: React.ReactNode }> = ({ active, onClick, children }) => (
  <button onClick={onClick}
    className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold ${active ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-400 hover:bg-gray-700'}`}>
    {children}
  </button>
);

const StatBar: React.FC<{ label: string; value: number; max: number; color: string }> = ({ label, value, max, color }) => (
  <div>
    <div className="flex justify-between text-[10px] text-gray-400 mb-0.5"><span>{label}</span><span className="tabular-nums">{value}</span></div>
    <div className="h-1.5 bg-gray-900 rounded-full overflow-hidden">
      <div className={`h-full ${color}`} style={{ width: `${Math.min(100, (value / max) * 100)}%` }} />
    </div>
  </div>
);

const Pill: React.FC<{ label: string; value: string; color: string }> = ({ label, value, color }) => (
  <div className="flex items-center gap-1.5 bg-gray-900/60 rounded px-1.5 py-1">
    <span className="w-2 h-2 rounded-full" style={{ background: color }} />
    <span className="text-gray-500">{label}:</span>
    <span className="text-gray-200 font-semibold">{value}</span>
  </div>
);

// ============================================================================
// WAR PLAN — uses barracks stockpile, shows power score per wave
// ============================================================================
const WarPlan: React.FC<{ target: ReturnType<typeof useEmpireStore.getState>['targets'][0] }> = ({ target }) => {
  const t = useT();
  const s = useEmpireStore();
  const plan = s.plan;
  const entryPoints: AttackEntry[] = ['orbital', 'north', 'south', 'east', 'west'];

  const totalArmyPower = computeArmyPower(plan.waves.flatMap(w => w.units));
  const enemyPower = target.layout.filter(d => !d.destroyed).reduce((sum, d) => sum + d.maxHp * 0.6, 0);
  const ratio = enemyPower > 0 ? totalArmyPower / enemyPower : 999;
  const verdict =
    ratio >= 1.8 ? { label: 'Vitória provável', color: 'text-emerald-300', bg: 'from-emerald-600 to-emerald-700' }
    : ratio >= 1.0 ? { label: 'Batalha equilibrada', color: 'text-amber-300', bg: 'from-amber-600 to-orange-700' }
    : { label: 'Risco alto', color: 'text-red-300', bg: 'from-red-700 to-red-900' };

  return (
    <div className="space-y-3">
      {/* Power-vs-power forecast bar */}
      <div className="rounded-xl bg-gray-950/70 border border-gray-800 p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="text-xs font-bold text-gray-300">⚖️ Previsão de Batalha</div>
          <span className={`text-[11px] font-bold ${verdict.color}`}>{verdict.label}</span>
        </div>
        <div className="grid grid-cols-2 gap-3 mb-2">
          <div>
            <div className="text-[10px] text-cyan-400 uppercase font-bold mb-0.5">Sua Força</div>
            <div className="text-xl font-black text-cyan-300 tabular-nums">⚡{totalArmyPower.toLocaleString()}</div>
          </div>
          <div className="text-right">
            <div className="text-[10px] text-red-400 uppercase font-bold mb-0.5">Defesa do Alvo</div>
            <div className="text-xl font-black text-red-300 tabular-nums">🛡️{Math.round(enemyPower).toLocaleString()}</div>
          </div>
        </div>
        <div className="h-2 bg-red-900/60 rounded-full overflow-hidden">
          <div className={`h-full bg-gradient-to-r ${verdict.bg}`} style={{ width: `${Math.min(100, ratio * 50)}%` }} />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div>
          {/* heroes */}
          <h3 className="text-sm font-bold text-gray-300 mb-2">{t('war.heroes')}</h3>
          <div className="grid grid-cols-2 gap-1.5 mb-4">
            {HEROES.map(h => (
              <button key={h.id} onClick={() => s.setHero(plan.heroId === h.id ? null : h.id)}
                className={`text-left p-2 rounded-lg border text-xs ${plan.heroId === h.id ? 'border-yellow-500 bg-yellow-950/20' : 'border-gray-800 bg-gray-900'}`}>
                <div className="font-bold text-white">{h.icon} {h.name}</div>
                <div className="text-[10px] text-gray-500">{h.title}</div>
                <div className="text-[10px] text-cyan-300 mt-0.5">{h.ability}</div>
                <div className="text-[10px] text-amber-400 mt-0.5">Custo: {h.cost.toLocaleString()}cr</div>
              </button>
            ))}
          </div>

          {/* entry point */}
          <h3 className="text-sm font-bold text-gray-300 mb-2">Ponto de Entrada</h3>
          <div className="flex flex-wrap gap-1.5 mb-4">
            {entryPoints.map(ep => (
              <button key={ep} onClick={() => s.setEntryPoint(ep)}
                className={`px-3 py-1 rounded text-xs font-semibold capitalize ${plan.entryPoint === ep ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-400'}`}>{ep}</button>
            ))}
          </div>
        </div>

        <div>
          {/* waves */}
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-bold text-gray-300">{t('war.waves')}</h3>
            <div className="flex gap-1">
              {BATTLE_LAYERS.map(l => (
                <button key={l} onClick={() => s.addWave(l)} title={LAYER_INFO[l].desc}
                  className="px-2 py-0.5 rounded text-[10px] bg-gray-800 hover:bg-gray-700 text-gray-300">{LAYER_INFO[l].icon}+</button>
              ))}
            </div>
          </div>
          <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
            {plan.waves.length === 0 && (
              <p className="text-xs text-gray-500">Adicione ondas por camada. Tropas vêm do seu Quartel (treine-as antes).</p>
            )}
            {plan.waves.map((w, idx) => {
              const wavePower = computeArmyPower(w.units);
              return (
                <div key={w.id} className="p-2 rounded-lg bg-gray-900 border border-gray-800">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-white">Onda {idx + 1} — {LAYER_INFO[w.layer].icon} {LAYER_INFO[w.layer].name}</span>
                    <div className="flex items-center gap-1.5">
                      <span className="text-[10px] text-amber-300 font-bold">⚡{wavePower.toLocaleString()}</span>
                      <button onClick={() => s.removeWave(w.id)} className="text-red-400"><Trash2 size={12} /></button>
                    </div>
                  </div>
                  <div className="space-y-1">
                    {ASSAULT_UNITS.filter(u => u.layer === w.layer).map(u => {
                      const cur = w.units.find(x => x.unitId === u.id)?.count || 0;
                      const stock = s.barracks.troops[u.id] || 0;
                      const power = computeUnitPower(u);
                      return (
                        <div key={u.id} className={`flex items-center gap-1.5 text-[11px] ${stock === 0 ? 'opacity-40' : 'text-gray-300'}`}>
                          <span className="flex-1">{u.icon} {u.name}
                            <span className="text-amber-400/80 ml-1">⚡{power}</span>
                            <span className="text-emerald-400/80 ml-1">[{stock}]</span>
                          </span>
                          <button onClick={() => s.setWaveUnit(w.id, u.id, Math.max(0, cur - 1))} className="p-0.5 bg-gray-800 rounded"><Minus size={10} /></button>
                          <span className="w-5 text-center tabular-nums">{cur}</span>
                          <button onClick={() => s.setWaveUnit(w.id, u.id, Math.min(stock, cur + 1))}
                            disabled={cur >= stock}
                            className="p-0.5 bg-gray-800 rounded disabled:opacity-30"><Plus size={10} /></button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>

          <button onClick={s.launchInvasion}
            className="w-full mt-3 py-2.5 rounded-lg bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-500 hover:to-orange-500 text-white font-bold text-sm flex items-center justify-center gap-2">
            <Rocket size={16} /> {t('war.launch')} — {target.name}
          </button>
        </div>
      </div>
    </div>
  );
};

type AttackEntry = 'orbital' | 'north' | 'south' | 'east' | 'west';


// ============================================================================
// REPLAY OVERLAY
// ============================================================================
const ReplayOverlay: React.FC = () => {
  const replay = useEmpireStore(s => s.currentReplay);
  const clearReplay = useEmpireStore(s => s.clearReplay);
  const [idx, setIdx] = useState(0);
  const [speed, setSpeed] = useState(1);

  React.useEffect(() => { setIdx(0); }, [replay?.id]);
  React.useEffect(() => {
    if (!replay) return;
    if (idx >= replay.frames.length - 1) return;
    const id = setTimeout(() => setIdx(i => Math.min(replay.frames.length - 1, i + 1)), 1200 / speed);
    return () => clearTimeout(id);
  }, [replay, idx, speed]);

  if (!replay) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 p-4" onClick={clearReplay}>
      <div className="bg-gray-950 border border-cyan-500/40 rounded-2xl w-full max-w-2xl p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold text-cyan-300">📺 Replay — {replay.targetName}</h2>
          <div className="flex items-center gap-1">
            {[0.5, 1, 2, 4].map(sp => (
              <button key={sp} onClick={() => setSpeed(sp)} className={`px-2 py-0.5 rounded text-[10px] font-bold ${speed === sp ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-400'}`}>{sp}x</button>
            ))}
            <button onClick={clearReplay} className="p-1.5 rounded-lg hover:bg-gray-800 text-gray-400 ml-1"><X size={18} /></button>
          </div>
        </div>
        <div className="flex items-center gap-2 mb-3">
          {[1, 2, 3].map(i => <Star key={i} size={20} className={i <= replay.stars ? 'text-yellow-400 fill-yellow-400' : 'text-gray-700'} />)}
          <span className="text-xs text-gray-400 ml-2">{replay.outcome} · saque {replay.lootGained} cr</span>
        </div>
        <div className="h-64 overflow-y-auto bg-black/50 rounded-lg border border-gray-800 p-3 space-y-1 font-mono text-xs">
          {replay.frames.slice(0, idx + 1).map((f, i) => (
            <div key={i} className={`${i === idx ? 'text-cyan-300' : 'text-gray-500'}`}>
              [{LAYER_INFO[f.layer].icon}] {f.text}
            </div>
          ))}
        </div>
        <div className="flex items-center gap-2 mt-3">
          <button onClick={() => setIdx(0)} className="px-3 py-1 rounded bg-gray-800 text-gray-300 text-xs flex items-center gap-1"><Play size={12} /> Reiniciar</button>
          <input type="range" min={0} max={replay.frames.length - 1} value={idx} onChange={(e) => setIdx(+e.target.value)} className="flex-1" />
          <span className="text-[10px] text-gray-500">{idx + 1}/{replay.frames.length}</span>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// TUTORIAL OVERLAY
// ============================================================================
const TUTORIAL_STEPS = [
  { title: 'Bem-vindo, Comandante!', body: 'Você comanda um império espalhado por várias galáxias. Não administra apenas o espaço — precisa equilibrar 5 frentes: Economia, Energia, Segurança, Ecologia e Saúde das suas cidades. Este tutorial guia você por TODOS os sistemas. Troque o idioma no botão da barra inferior quando quiser.', hint: 'Clique em "Próximo" para começar.' },
  { title: '1 · Navegue pelo universo', body: 'Use a barra lateral à esquerda para alternar entre Galáxia, Sistema, Planeta e Frota. Na vista da galáxia, clique numa estrela para entrar no sistema; clique num planeta para vê-lo de perto.', hint: '➡️ Passe o mouse na barra esquerda e clique em "Galaxy Map".' },
  { title: '2 · Encontre um mundo habitável', body: 'Entre num sistema e clique nos planetas. No painel à direita veja a Habitabilidade. Planetas com 25%+ podem ser colonizados. Quanto maior a habitabilidade, melhor a cidade cresce.', hint: '➡️ Selecione um planeta verde/azul com boa habitabilidade.' },
  { title: '3 · Estabeleça sua primeira colônia', body: 'No painel do planeta clique em "ESTABLISH COLONY". Isso funda uma cidade e marca o planeta como seu. Cada planeta colonizado abre minas e cidades para administrar.', hint: '➡️ Clique no botão verde ESTABLISH COLONY.' },
  { title: '4 · Abra Mineração', body: 'Abra o painel "Colônias" na barra inferior. Na coluna de Mineração, escolha um depósito do seu planeta e construa uma Mina (800c). As minas extraem matéria-prima automaticamente para o seu estoque — a base de toda a economia.', hint: '➡️ Barra inferior → 🏙️ Colônias → construir Mina.' },
  { title: '5 · Faça crescer suas cidades', body: 'Ainda em Colônias, abra "Investir e expandir cidade". Cada distrito custa créditos + materiais e melhora UMA das 5 dimensões e/ou a capacidade populacional. Cidades sobem de nível conforme você investe — e ficam maiores no mapa 3D!', hint: '➡️ Clique em "Ver 3D" para visualizar a cidade crescer.' },
  { title: '6 · Equilíbrio é tudo (dificuldade)', body: 'As 5 dimensões CAEM com o tempo e com a superlotação. Energia baixa causa blecaute; Segurança ou Saúde baixas causam revolta e travam a renda; Ecologia baixa reduz o crescimento. Industrializar dá renda mas polui. Você precisa investir continuamente.', hint: '⚠️ Fique de olho nas barras vermelhas.' },
  { title: '7 · Indústria e cadeia produtiva', body: 'Abra Indústria. Construa máquinas (Forno, Fundição, Montadora...) e dê uma receita a cada uma. A cadeia vai de minério → metal refinado → ligas → componentes → módulos → edifícios avançados. Esses materiais alimentam cidades, construções e guerra.', hint: '➡️ Barra inferior → 🏭 Indústria.' },
  { title: '8 · Mercado e logística', body: 'No Mercado, venda excedentes e compre o que falta. Cuidado com energia: reatores geram, fábricas consomem. Use logística para mover recursos entre planetas.', hint: '➡️ Barra inferior → 🛒 Mercado.' },
  { title: '9 · Bolsa de Componentes', body: 'Abra "Componentes". Os preços de peças de engenharia flutuam com a demanda do mercado. Compre na baixa e venda na alta para lucrar — uma economia viva de preço e demanda.', hint: '➡️ Barra inferior → 📈 Componentes.' },
  { title: '10 · Engenharia de robôs', body: 'Abra Engenharia: 1000+ peças e comportamentos programáveis. Combine chassis, locomoção, sensores, armas, IA e blocos de comportamento para criar robôs reais, visualizá-los em 3D e vendê-los.', hint: '➡️ Barra inferior → 🧠 Engenharia.' },
  { title: '11 · Construção (Estaleiro)', body: 'No Estaleiro construa satélites, drones, veículos, estações, frotas, naves capitais e megaestruturas. Satélites podem ser lançados sobre seus planetas. Cada item exige materiais específicos da sua indústria.', hint: '➡️ Barra inferior → 🔨 Construir.' },
  { title: '12 · Guerra galáctica', body: 'Faça reconhecimento (sondas, espiões, hackers) para revelar a base inimiga. Planeje ondas por camada: Órbita → Atmosfera → Desembarque → Combate Urbano. Escolha heróis e o ponto de entrada.', hint: '➡️ Barra inferior → ⚔️ Guerra.' },
  { title: '13 · Estrelas, missões e tarefas', body: 'Ganhe até 3 estrelas destruindo o Centro Administrativo, capturando infraestrutura e parando a produção. Cumpra Missões por recompensas. E use a 🗒️ Central de Tarefas (botão na barra) que sempre mostra o que precisa ser feito agora.', hint: '➡️ Abra a Central de Tarefas a qualquer momento.' },
  { title: 'Pronto para reinar!', body: 'Você já conhece todos os sistemas. Comece minerando e fundando cidades, equilibre as 5 dimensões, expanda a indústria e parta para a conquista. Boa sorte, Comandante!', hint: '🚀 Clique em "Começar a jogar!"' },
];

const TutorialOverlay: React.FC = () => {
  const { tutorialOpen, tutorialStep, setTutorialStep, finishTutorial, closeTutorial } = useEmpireStore();
  if (!tutorialOpen) return null;
  const step = TUTORIAL_STEPS[tutorialStep];
  const last = tutorialStep === TUTORIAL_STEPS.length - 1;
  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center bg-black/40 p-4 pb-28 pointer-events-none">
      <div className="bg-gray-950 border border-indigo-500/40 rounded-2xl w-full max-w-lg p-6 shadow-2xl pointer-events-auto">
        <div className="flex items-center gap-2 mb-3">
          <GraduationCap className="text-indigo-400" size={22} />
          <span className="text-[10px] text-gray-500">Passo {tutorialStep + 1} de {TUTORIAL_STEPS.length}</span>
          <button onClick={closeTutorial} className="ml-auto p-1 rounded hover:bg-gray-800 text-gray-500"><X size={16} /></button>
        </div>
        <h2 className="text-xl font-bold text-white mb-2">{step.title}</h2>
        <p className="text-sm text-gray-300 leading-relaxed">{step.body}</p>
        {step.hint && <p className="mt-3 text-xs text-indigo-300 bg-indigo-500/10 border border-indigo-500/30 rounded-lg px-3 py-2">{step.hint}</p>}
        <div className="flex items-center justify-between mt-5">
          <button disabled={tutorialStep === 0} onClick={() => setTutorialStep(tutorialStep - 1)}
            className="px-3 py-1.5 rounded-lg bg-gray-800 text-gray-300 text-xs font-semibold disabled:opacity-30">Anterior</button>
          <div className="flex gap-1">
            {TUTORIAL_STEPS.map((_, i) => <div key={i} className={`w-1.5 h-1.5 rounded-full ${i === tutorialStep ? 'bg-indigo-400' : 'bg-gray-700'}`} />)}
          </div>
          {last ? (
            <button onClick={finishTutorial} className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold">Começar a jogar!</button>
          ) : (
            <button onClick={() => setTutorialStep(tutorialStep + 1)} className="px-4 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold">Próximo</button>
          )}
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// Root overlay manager
// ============================================================================
export const EmpireOverlays: React.FC = () => {
  const panel = useEmpireUI(s => s.panel);
  return (
    <>
      {panel === 'colonies' && <ColonyPanel />}
      {panel === 'colonization' && <ColonizationPanel />}
      {panel === 'industry' && <IndustryPanel />}
      {panel === 'market' && <MarketPanel />}
      {panel === 'components' && <ComponentExchange />}
      {panel === 'build' && <BuildPanel />}
      {panel === 'war' && <WarPanel />}
      {panel === 'missions' && <MissionsPanel />}
      {panel === 'engineering' && <EngineeringCatalogPanel />}
      {panel === 'tasks' && <TaskCenter />}
      <TutorialOverlay />
    </>
  );
};
