// ============================================================================
// GALACTIC EVENTS PANEL — Random events that shape the galaxy
// ============================================================================
import React, { useState } from 'react';
import { X, AlertTriangle, Clock, CheckCircle, Zap } from 'lucide-react';
import { create } from 'zustand';
import { useGameStore } from './gameStore';
import {
  GALACTIC_EVENTS, EVENT_BY_ID, SEVERITY_INFO, type GalacticEvent, type EventSeverity,
} from './data/galacticEventsData';

// ============================================================================
// STORE
// ============================================================================
export interface ActiveGalacticEvent {
  id: string;
  eventId: string;
  firedAt: number;
  resolved: boolean;
  chosenOption?: string;
  expiredAt?: number;
}

interface GalacticEventsState {
  activeEvents: ActiveGalacticEvent[];
  eventHistory: ActiveGalacticEvent[];
  pendingEvent: ActiveGalacticEvent | null;
  showPanel: boolean;
  showNotificationBadge: boolean;
  lastEventCheckedAt: number;

  openPanel: () => void;
  closePanel: () => void;
  tick: (delta: number) => void;
  resolveEvent: (eventId: string, choiceId: string) => void;
  dismissPendingEvent: () => void;
}

let evCounter = 0;
const newEvId = () => `gev_${evCounter++}`;

export const useGalacticEventsStore = create<GalacticEventsState>((set, get) => ({
  activeEvents: [],
  eventHistory: [],
  pendingEvent: null,
  showPanel: false,
  showNotificationBadge: false,
  lastEventCheckedAt: 0,

  openPanel: () => set({ showPanel: true, showNotificationBadge: false }),
  closePanel: () => set({ showPanel: false }),

  tick: (delta) => {
    const g = useGameStore.getState();
    if (g.paused || g.gameTime < 500) return;
    const dt = delta * g.gameSpeed;

    const state = get();
    if (state.pendingEvent) return; // already showing event

    // Check for new events
    const timeSinceLast = g.gameTime - state.lastEventCheckedAt;
    if (timeSinceLast < 200) return;

    for (const ev of GALACTIC_EVENTS) {
      if (ev.prereqTurns && g.gameTime < ev.prereqTurns) continue;

      const wasRecentlyUsed = state.eventHistory.some(h => {
        if (h.eventId !== ev.id) return false;
        return (g.gameTime - h.firedAt) < ev.cooldown;
      });
      if (wasRecentlyUsed) continue;

      const maxTimes = ev.repeatableMax;
      if (maxTimes !== undefined) {
        const usedTimes = state.eventHistory.filter(h => h.eventId === ev.id).length;
        if (usedTimes >= maxTimes) continue;
      }

      // Roll for event
      if (Math.random() < ev.probability * dt) {
        const newActive: ActiveGalacticEvent = {
          id: newEvId(),
          eventId: ev.id,
          firedAt: g.gameTime,
          resolved: false,
        };
        set({
          pendingEvent: newActive,
          lastEventCheckedAt: g.gameTime,
          showNotificationBadge: true,
        });
        return;
      }
    }

    set({ lastEventCheckedAt: g.gameTime });
  },

  resolveEvent: (activeEventId, choiceId) => {
    const { pendingEvent } = get();
    if (!pendingEvent || pendingEvent.id !== activeEventId) return;

    const g = useGameStore.getState();
    const ev = EVENT_BY_ID[pendingEvent.eventId];
    if (!ev) return;

    const choice = ev.choices.find(c => c.id === choiceId);
    if (!choice) return;

    // Apply outcomes
    const out = choice.outcome;
    if (out.credits) g.addCredits(out.credits);
    if (out.resources) {
      // Can't directly set resources on gameStore easily, notify instead
      g.addNotification({ type: 'success', message: `Recursos recebidos: ${Object.entries(out.resources).map(([k, v]) => `${v > 0 ? '+' : ''}${v} ${k}`).join(', ')}` });
    }
    if (choice.creditCost) {
      g.spendCredits(choice.creditCost);
    }
    if (out.specialEffect) {
      g.addNotification({ type: 'info', message: `✨ Efeito especial ativo: ${out.specialEffect.replace(/_/g, ' ')}` });
    }

    const resolved = { ...pendingEvent, resolved: true, chosenOption: choiceId };
    set(s => ({
      pendingEvent: null,
      eventHistory: [resolved, ...s.eventHistory].slice(0, 50),
      activeEvents: s.activeEvents.filter(e => e.id !== activeEventId),
    }));
  },

  dismissPendingEvent: () => {
    const { pendingEvent } = get();
    if (!pendingEvent) return;
    set(s => ({
      pendingEvent: null,
      eventHistory: [{ ...pendingEvent, resolved: true }, ...s.eventHistory].slice(0, 50),
    }));
  },
}));

// ============================================================================
// EVENT POPUP (shown during gameplay)
// ============================================================================
export const GalacticEventPopup: React.FC = () => {
  const { pendingEvent, resolveEvent, dismissPendingEvent } = useGalacticEventsStore();
  if (!pendingEvent) return null;

  const ev = EVENT_BY_ID[pendingEvent.eventId];
  if (!ev) return null;

  const sevInfo = SEVERITY_INFO[ev.severity];

  return (
    <div className="fixed inset-0 z-[55] flex items-center justify-center bg-black/60 p-4">
      <div className="w-full max-w-lg rounded-2xl overflow-hidden border"
           style={{ borderColor: `${sevInfo.color}50`, background: 'linear-gradient(135deg, rgba(8,8,20,0.98), rgba(4,4,12,0.99))' }}>

        {/* Severity bar */}
        <div className="h-1" style={{ background: sevInfo.color }} />

        <div className="p-6 space-y-4">
          {/* Header */}
          <div className="flex items-start gap-4">
            <div className="text-5xl">{ev.icon}</div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-bold px-2 py-0.5 rounded uppercase tracking-wider"
                      style={{ color: sevInfo.color, background: `${sevInfo.color}20`, border: `1px solid ${sevInfo.color}40` }}>
                  {sevInfo.label}
                </span>
                <span className="text-xs text-gray-500 capitalize">{ev.category}</span>
              </div>
              <h3 className="font-bold text-white text-lg">{ev.title}</h3>
            </div>
          </div>

          {/* Description */}
          <p className="text-gray-300 text-sm">{ev.description}</p>

          {/* Flavor */}
          <div className="p-3 rounded-lg bg-gray-900/60 border border-gray-800 text-gray-400 text-xs italic">
            {ev.flavorText}
          </div>

          {/* Choices */}
          <div className="space-y-2">
            <div className="text-xs text-gray-400 font-bold uppercase tracking-wider">Sua Decisão</div>
            {ev.choices.map(choice => (
              <button
                key={choice.id}
                onClick={() => resolveEvent(pendingEvent.id, choice.id)}
                className="w-full text-left p-3 rounded-xl border border-gray-700 bg-gray-900/60 hover:border-cyan-500/40 hover:bg-gray-800/60 transition-all group"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="font-bold text-white text-sm group-hover:text-cyan-300 transition-colors">{choice.label}</div>
                    <div className="text-xs text-gray-400 mt-0.5">{choice.desc}</div>
                  </div>
                  <div className="flex flex-col items-end gap-1 ml-3 flex-shrink-0">
                    {choice.creditCost && (
                      <span className="text-xs text-red-400">-{choice.creditCost.toLocaleString()} cr</span>
                    )}
                    {choice.outcome.credits && choice.outcome.credits > 0 && (
                      <span className="text-xs text-green-400">+{choice.outcome.credits.toLocaleString()} cr</span>
                    )}
                    {choice.outcome.researchBoost && (
                      <span className="text-xs text-purple-400">+{choice.outcome.researchBoost} pesq</span>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>

          <button onClick={dismissPendingEvent} className="w-full py-2 rounded-lg border border-gray-700 text-gray-500 text-xs hover:text-gray-300 hover:border-gray-600 transition-colors">
            Ignorar
          </button>
        </div>
      </div>
    </div>
  );
};

// ============================================================================
// MAIN PANEL — History of all events
// ============================================================================
export const GalacticEventsPanel: React.FC = () => {
  const { showPanel, closePanel, eventHistory } = useGalacticEventsStore();
  const [filter, setFilter] = useState<EventSeverity | null>(null);

  if (!showPanel) return null;

  const filtered = eventHistory.filter(e => {
    const ev = EVENT_BY_ID[e.eventId];
    if (!ev) return false;
    if (filter && ev.severity !== filter) return false;
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="w-full max-w-2xl h-[85vh] flex flex-col rounded-2xl border border-purple-500/30 overflow-hidden"
           style={{ background: 'linear-gradient(135deg, rgba(10,5,20,0.98), rgba(5,3,10,0.99))' }}>

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <AlertTriangle size={22} className="text-amber-400" />
            <div>
              <h2 className="font-display text-xl font-bold text-white tracking-wider">EVENTOS GALÁCTICOS</h2>
              <p className="text-xs text-gray-400 font-mono-hud">{eventHistory.length} eventos no histórico</p>
            </div>
          </div>
          <button onClick={closePanel} className="p-2 rounded-lg hover:bg-gray-800 text-gray-400">
            <X size={20} />
          </button>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2 px-6 py-3 border-b border-gray-800/50">
          {([null, 'minor', 'moderate', 'major', 'catastrophic'] as (EventSeverity | null)[]).map(sev => {
            const info = sev ? SEVERITY_INFO[sev] : null;
            return (
              <button
                key={String(sev)}
                onClick={() => setFilter(sev)}
                className={`px-3 py-1 text-xs rounded transition-colors font-bold`}
                style={
                  filter === sev
                    ? { background: info?.color || '#6b7280', color: 'white' }
                    : { background: '#1f2937', color: info?.color || '#9ca3af' }
                }
              >
                {sev === null ? 'Todos' : (info?.label || sev)}
              </button>
            );
          })}
        </div>

        {/* Event list */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filtered.length === 0 ? (
            <div className="text-center py-16 text-gray-500">
              <Zap size={48} className="mx-auto mb-4 text-gray-700" />
              <p className="text-lg font-bold text-gray-400">Nenhum evento ainda</p>
              <p className="text-sm mt-2">Eventos galácticos surgirão à medida que seu império crescer.</p>
            </div>
          ) : filtered.map(ae => {
            const ev = EVENT_BY_ID[ae.eventId];
            if (!ev) return null;
            const sevInfo = SEVERITY_INFO[ev.severity];
            return (
              <div key={ae.id} className="p-4 rounded-xl border border-gray-800 bg-gray-900/60">
                <div className="flex items-start gap-3">
                  <div className="text-3xl flex-shrink-0">{ev.icon}</div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="font-bold text-white text-sm">{ev.title}</h4>
                      <span className="text-xs px-1.5 py-0.5 rounded font-bold"
                            style={{ color: sevInfo.color, background: `${sevInfo.color}20` }}>
                        {sevInfo.label}
                      </span>
                      {ae.resolved && <CheckCircle size={12} className="text-green-400" />}
                    </div>
                    <p className="text-gray-400 text-xs mt-1">{ev.description}</p>
                    {ae.chosenOption && (
                      <div className="mt-1 text-xs text-cyan-400">
                        Decisão: {ev.choices.find(c => c.id === ae.chosenOption)?.label || ae.chosenOption}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
