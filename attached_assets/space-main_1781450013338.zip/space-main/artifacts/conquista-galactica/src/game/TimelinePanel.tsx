import React, { useMemo, useState } from 'react';
import { useGameStore, type TimelineCategory } from './gameStore';
import { X, BookOpen } from 'lucide-react';

const CATEGORY_LABEL: Record<TimelineCategory, string> = {
  foundation: 'Fundação',
  war: 'Guerra',
  discovery: 'Descoberta',
  colony: 'Colônia',
  death: 'Morte de líder',
  collapse: 'Colapso',
  invention: 'Invenção',
  cosmic: 'Evento cósmico',
  diplomacy: 'Diplomacia',
  economy: 'Economia',
  tech: 'Tecnologia',
  misc: 'Outros',
};

const CATEGORY_COLOR: Record<TimelineCategory, string> = {
  foundation: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
  war: 'bg-red-500/20 text-red-300 border-red-500/40',
  discovery: 'bg-blue-500/20 text-blue-300 border-blue-500/40',
  colony: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
  death: 'bg-gray-500/20 text-gray-300 border-gray-500/40',
  collapse: 'bg-orange-500/20 text-orange-300 border-orange-500/40',
  invention: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
  cosmic: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
  diplomacy: 'bg-pink-500/20 text-pink-300 border-pink-500/40',
  economy: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40',
  tech: 'bg-fuchsia-500/20 text-fuchsia-300 border-fuchsia-500/40',
  misc: 'bg-gray-500/20 text-gray-300 border-gray-500/40',
};

export const TimelinePanel: React.FC = () => {
  const { showTimeline, toggleTimeline, timeline } = useGameStore();
  const [filter, setFilter] = useState<'all' | TimelineCategory>('all');
  const [search, setSearch] = useState('');

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return [...timeline]
      .sort((a, b) => b.time - a.time)
      .filter(e => {
        if (filter !== 'all' && e.category !== filter) return false;
        if (!q) return true;
        return (
          e.title.toLowerCase().includes(q) ||
          e.description.toLowerCase().includes(q) ||
          (e.location?.toLowerCase().includes(q) ?? false)
        );
      });
  }, [timeline, filter, search]);

  if (!showTimeline) return null;

  return (
    <div className="fixed inset-0 z-50 bg-gray-950 text-white flex flex-col">
      <div className="h-14 bg-gray-900 border-b border-cyan-500/30 flex items-center px-4 gap-4">
        <button onClick={toggleTimeline} className="p-2 bg-gray-800 hover:bg-gray-700 rounded">
          <X size={18} />
        </button>
        <BookOpen size={20} className="text-cyan-400" />
        <h2 className="text-lg font-bold">Linha do Tempo Universal · Enciclopédia</h2>
        <span className="ml-auto text-sm text-gray-400">{timeline.length} registros históricos</span>
      </div>

      <div className="p-3 border-b border-gray-800 flex flex-wrap items-center gap-2 bg-gray-900/50">
        <input
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Buscar evento, lugar ou descrição..."
          className="px-3 py-2 bg-gray-800 rounded text-sm w-72 outline-none focus:ring-1 focus:ring-cyan-500"
        />
        {(['all', ...Object.keys(CATEGORY_LABEL)] as (TimelineCategory | 'all')[]).map(c => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            className={`px-2 py-1 text-xs rounded ${
              filter === c ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {c === 'all' ? 'Tudo' : CATEGORY_LABEL[c as TimelineCategory]}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto">
          {filtered.length === 0 && (
            <div className="text-center text-gray-500 py-20">
              Nenhum evento registrado ainda. Conforme o universo evolui, sua história aparecerá aqui.
            </div>
          )}
          <ol className="relative border-l-2 border-gray-800 ml-3">
            {filtered.map(e => {
              const days = Math.floor(e.time % 365);
              return (
                <li key={e.id} className="ml-6 mb-6">
                  <span className="absolute -left-2.5 w-5 h-5 rounded-full bg-gray-900 border-2 border-cyan-500" />
                  <div className={`px-4 py-3 rounded border ${CATEGORY_COLOR[e.category]}`}>
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-bold">Ano {e.year} · Dia {days}</span>
                      <span className="opacity-70">·</span>
                      <span className="uppercase tracking-wide opacity-70">{CATEGORY_LABEL[e.category]}</span>
                      <span className="ml-auto">{'★'.repeat(e.importance)}</span>
                    </div>
                    <div className="text-base font-bold mt-1">{e.title}</div>
                    <div className="text-sm opacity-90 mt-1">{e.description}</div>
                    {e.location && (
                      <div className="text-xs opacity-70 mt-1">📍 {e.location}</div>
                    )}
                  </div>
                </li>
              );
            })}
          </ol>
        </div>
      </div>
    </div>
  );
};