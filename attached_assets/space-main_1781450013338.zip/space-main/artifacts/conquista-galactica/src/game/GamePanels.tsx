import React from 'react';
import { useGameStore } from './gameStore';
import { useEmpireUI } from './empireUI';
import { useColonizationStore } from './colonizationStore';
import {
  Play,
  Pause,
  Globe,
  Star,
  Rocket,
  Bell,
  Zap,
  Droplets,
  Package,
  HeartPulse,
  Shield,
  Globe2,
  Flag,
  MapPin,
  Gauge,
  Thermometer,
  Wind,
  BookOpen,
  Wrench
} from 'lucide-react';

// Top bar
export const TopBar: React.FC = () => {
  const {
    gameTime,
    gameSpeed,
    paused,
    setGameSpeed,
    togglePause,
    notifications,
    saveGame,
    loadGame,
    originWorld
  } = useGameStore();

  const unread = notifications.filter(n => !n.read).length;
  const years = Math.floor(gameTime / 365);
  const days = Math.floor(gameTime % 365);

  return (
    <div className="fixed top-0 left-0 right-0 h-12 bg-gray-900/95 border-b border-cyan-500/30 z-40 flex items-center px-3">
      <div className="flex items-center gap-2 w-48">
        <Globe2 className="text-cyan-400" size={20} />
        <span className="font-bold text-white text-sm">CONQUISTA GALACTICA</span>
      </div>

      <div className="flex items-center gap-2 px-3 py-1 bg-cyan-500/10 border border-cyan-500/30 rounded">
        <Flag className="text-cyan-400" size={12} />
        <span className="text-cyan-400 text-xs font-bold">ORIGIN: {originWorld?.name || 'Terra'}</span>
      </div>

      <div className="flex items-center gap-2 ml-auto">
        <div className="px-3 py-1 bg-gray-800 rounded text-sm">
          <span className="text-gray-400">Year {years} Day {days}</span>
        </div>

        <div className="flex border border-gray-700 rounded overflow-hidden">
          <button onClick={togglePause} className={`px-2 py-1.5 ${paused ? 'bg-green-600' : 'bg-gray-800'}`}>
            {paused ? <Play size={16} className="text-white" /> : <Pause size={16} className="text-white" />}
          </button>
          {[1, 2, 5, 10, 20].map(s => (
            <button
              key={s}
              onClick={() => setGameSpeed(s)}
              className={`px-3 py-1.5 text-xs font-bold transition-colors
                ${gameSpeed === s ? 'bg-cyan-600 text-white' : 'bg-gray-800 text-gray-400 hover:text-white'}`}
            >
              {s}x
            </button>
          ))}
        </div>
      </div>

      <div className="relative ml-3">
        <button className="p-1.5 bg-gray-800 rounded">
          <Bell className="text-white" size={16} />
          {unread > 0 && (
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-4 h-4 rounded-full flex items-center justify-center">
              {unread}
            </span>
          )}
        </button>
      </div>

      <div className="flex gap-2 ml-3">
        <button onClick={saveGame} className="px-2 py-1 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded text-xs">Save</button>
        <button onClick={loadGame} className="px-2 py-1 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded text-xs">Load</button>
      </div>
      <TopBarExtra />
    </div>
  );
};

const TopBarExtra: React.FC = () => {
  const { toggleTimeline, toggleEngineering, timeline, robots } = useGameStore();
  return (
    <div className="flex gap-2 ml-3">
      <button
        onClick={toggleTimeline}
        title="Linha do Tempo Universal"
        className="px-2 py-1 bg-indigo-700/40 hover:bg-indigo-600/60 text-indigo-200 rounded text-xs flex items-center gap-1"
      >
        <BookOpen size={14} /> Linha do Tempo
        <span className="ml-1 px-1.5 rounded bg-indigo-900/80 text-indigo-200">{timeline.length}</span>
      </button>
      <button
        onClick={toggleEngineering}
        title="Engenharia / Robôs"
        className="px-2 py-1 bg-emerald-700/40 hover:bg-emerald-600/60 text-emerald-200 rounded text-xs flex items-center gap-1"
      >
        <Wrench size={14} /> Engenharia
        <span className="ml-1 px-1.5 rounded bg-emerald-900/80 text-emerald-200">{robots.length}</span>
      </button>
    </div>
  );
};

// Sidebar
export const SideBar: React.FC = () => {
  const { currentView, setCurrentView, toggleShipInterior, showShipInterior, playerShips, galaxies, selectedStar, selectedPlanet } = useGameStore();

  const totalColonies = galaxies.reduce((sum, g) =>
    sum + g.stars.reduce((s, star) =>
      s + star.planets.reduce((ps, p) => ps + p.colonies.length, 0), 0), 0);

  const navItems = [
    { id: 'galaxy', icon: Globe2, label: 'Galaxy Map' },
    { id: 'system', icon: Star, label: 'System', disabled: !selectedStar },
    { id: 'planet', icon: Globe, label: 'Planet', disabled: !selectedPlanet },
    { id: 'ship', icon: Rocket, label: `Fleet (${playerShips.length})`, action: toggleShipInterior, active: showShipInterior }
  ];

  return (
    <div className="fixed left-0 top-12 bottom-0 w-14 hover:w-48 bg-gray-900/95 border-r border-cyan-500/30 z-30 transition-all duration-200 overflow-hidden group">
      <div className="py-3 space-y-1">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = item.active || (currentView === item.id && !item.action);
          return (
            <button
              key={item.id}
              onClick={() => item.action ? item.action() : setCurrentView(item.id as 'galaxy' | 'system' | 'planet' | 'ship')}
              disabled={item.disabled}
              className={`w-full flex items-center gap-3 px-4 py-2.5 transition-colors
                ${isActive ? 'bg-cyan-600/20 text-cyan-400 border-l-2 border-cyan-400' :
                  item.disabled ? 'text-gray-600 cursor-not-allowed' : 'text-gray-400 hover:bg-gray-800 hover:text-white'}`}
            >
              <Icon size={20} className="flex-shrink-0" />
              <span className="font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity text-sm">
                {item.label}
              </span>
            </button>
          );
        })}

        <div className="border-t border-gray-700 my-3" />

        <div className="px-4 space-y-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="text-xs text-gray-500 font-bold uppercase">Statistics</div>
          <div className="text-xs text-gray-400">Galaxies: {galaxies.length}</div>
          <div className="text-xs text-gray-400">Colonies: {totalColonies}</div>
          <div className="text-xs text-gray-400">Ships: {playerShips.length}</div>
        </div>
      </div>
    </div>
  );
};

// Resource panel
export const ResourcePanel: React.FC = () => {
  const { resources } = useGameStore();

  const icons: Record<string, { icon: React.ReactNode; color: string }> = {
    energy: { icon: <Zap size={14} />, color: 'text-yellow-400' },
    food: { icon: <Droplets size={14} />, color: 'text-green-400' },
    water: { icon: <Droplets size={14} />, color: 'text-blue-400' },
    iron: { icon: <Package size={14} />, color: 'text-gray-400' },
    fuel: { icon: <Zap size={14} />, color: 'text-purple-400' },
    electronics: { icon: <Package size={14} />, color: 'text-cyan-400' },
    medicine: { icon: <HeartPulse size={14} />, color: 'text-pink-400' },
    titanium: { icon: <Package size={14} />, color: 'text-slate-300' },
    copper: { icon: <Package size={14} />, color: 'text-orange-400' },
    crystals: { icon: <Package size={14} />, color: 'text-purple-300' }
  };

  return (
    <div className="fixed right-4 top-16 w-56 bg-gray-900/95 border border-cyan-500/30 rounded-lg z-30 p-3">
      <h3 className="text-cyan-400 font-bold mb-3 flex items-center gap-2 text-sm">
        <Zap size={16} />
        RESOURCES
      </h3>

      <div className="space-y-2">
        {resources.slice(0, 6).map(res => {
          const cfg = icons[res.resource] || { icon: <Package size={14} />, color: 'text-gray-400' };
          const pct = (res.amount / res.maxStorage) * 100;
          const net = res.production - res.consumption;

          return (
            <div key={res.resource} className="space-y-0.5">
              <div className="flex items-center justify-between text-xs">
                <div className={`flex items-center gap-1.5 ${cfg.color}`}>
                  {cfg.icon}
                  <span className="capitalize">{res.resource}</span>
                </div>
                <span className="text-white font-bold">{Math.floor(res.amount)}</span>
              </div>
              <div className="w-full h-1.5 bg-gray-700 rounded-full">
                <div
                  className={`h-1.5 rounded-full ${pct > 80 ? 'bg-green-500' : pct > 40 ? 'bg-yellow-500' : 'bg-red-500'}`}
                  style={{ width: `${Math.min(100, pct)}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// Planet info panel
export const PlanetInfoPanel: React.FC = () => {
  const { selectedPlanet, originWorld, currentView, showShipInterior } = useGameStore();
  const setEmpirePanel = useEmpireUI(s => s.setPanel);
  const openColonization = useColonizationStore(s => s.openPanelFor);
  const missions = useColonizationStore(s => s.missions);

  if (!selectedPlanet || showShipInterior || currentView !== 'planet') return null;

  const dist = Math.sqrt(
    (selectedPlanet.position.x - originWorld.position.x) ** 2 +
    (selectedPlanet.position.y - originWorld.position.y) ** 2 +
    (selectedPlanet.position.z - originWorld.position.z) ** 2
  );

  const canCol = selectedPlanet.habitability >= 0.25 && selectedPlanet.colonies.length === 0;
  const inProgress = missions.find(m => m.planetId === selectedPlanet.id && m.phase !== 'complete' && m.phase !== 'failed');

  return (
    <div className="fixed right-4 top-56 w-64 bg-gray-900/95 border border-cyan-500/30 rounded-lg z-30 p-3">
      <h3 className="text-cyan-400 font-bold mb-3 flex items-center gap-2 text-sm">
        <Globe size={16} />
        {selectedPlanet.name}
      </h3>

      <div className="space-y-2 text-xs">
        <div className="flex justify-between">
          <span className="text-gray-400">Type</span>
          <span className="text-white capitalize">{selectedPlanet.type.replace('_', ' ')}</span>
        </div>

        <div className="flex justify-between">
          <span className="text-gray-400">Habitability</span>
          <span className={selectedPlanet.habitability > 0.5 ? 'text-green-400' : selectedPlanet.habitability > 0.25 ? 'text-yellow-400' : 'text-red-400'}>
            {(selectedPlanet.habitability * 100).toFixed(0)}%
          </span>
        </div>

        <div className="flex justify-between">
          <span className="text-gray-400 flex items-center gap-1"><Thermometer size={10} /> Temp</span>
          <span className={Math.abs(selectedPlanet.temperature - 20) < 30 ? 'text-green-400' : 'text-red-400'}>
            {selectedPlanet.temperature.toFixed(0)}C
          </span>
        </div>

        <div className="flex justify-between">
          <span className="text-gray-400">Gravity</span>
          <span className="text-white">{selectedPlanet.gravity.toFixed(2)}g</span>
        </div>

        <div className="flex justify-between">
          <span className="text-gray-400 flex items-center gap-1"><MapPin size={10} /> Distance</span>
          <span className="text-orange-400">{dist.toFixed(1)} LY</span>
        </div>

        {selectedPlanet.atmosphere && (
          <div className="flex justify-between">
            <span className="text-gray-400 flex items-center gap-1"><Wind size={10} /> Atmo</span>
            <span className={selectedPlanet.atmosphereType === 'breathable' ? 'text-green-400' : 'text-yellow-400'}>
              {selectedPlanet.atmosphereType}
            </span>
          </div>
        )}

        <div className="flex justify-between">
          <span className="text-gray-400">Population</span>
          <span className="text-white">{selectedPlanet.population?.toLocaleString() || 'None'}</span>
        </div>

        {selectedPlanet.colonies.length > 0 && (
          <div className="pt-2 border-t border-gray-700">
            <span className="text-gray-400 block mb-1">Colonies</span>
            {selectedPlanet.colonies.map(c => (
              <div key={c.id} className="p-1.5 bg-gray-800 rounded text-xs mb-1">
                <div className="font-bold text-white">{c.name}</div>
                <div className="text-gray-400">{c.population.toLocaleString()} pop</div>
              </div>
            ))}
          </div>
        )}

        {!selectedPlanet.owned && canCol && !inProgress && (
          <button
            onClick={() => { openColonization(selectedPlanet.id); setEmpirePanel('colonization'); }}
            className="w-full mt-3 flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-purple-500 hover:shadow-[0_0_18px_rgba(34,211,238,0.6)]
              text-white font-bold py-2 rounded text-xs transition-all"
          >
            <Flag size={14} />
            PLANEJAR COLONIZAÇÃO
          </button>
        )}
        {inProgress && (
          <button
            onClick={() => { openColonization(selectedPlanet.id); setEmpirePanel('colonization'); }}
            className="w-full mt-3 flex items-center justify-center gap-2 bg-amber-600 hover:bg-amber-500
              text-white font-bold py-2 rounded text-xs transition-colors animate-pulse"
          >
            <Flag size={14} />
            MISSÃO EM CURSO — VER STATUS
          </button>
        )}
      </div>
    </div>
  );
};

// Fleet mini panel
export const FleetMiniPanel: React.FC = () => {
  const { playerShips, selectShip, toggleShipInterior, showShipInterior, currentView } = useGameStore();

  if (playerShips.length === 0 || showShipInterior || currentView === 'galaxy') return null;

  return (
    <div className="fixed left-16 bottom-4 bg-gray-900/95 border border-cyan-500/30 rounded-lg z-30 p-2">
      <div className="flex items-center gap-2">
        {playerShips.map(ship => (
          <button
            key={ship.id}
            onClick={() => { selectShip(ship); toggleShipInterior(); }}
            className="flex flex-col items-center p-2 rounded bg-gray-800 hover:bg-gray-700 transition-colors"
          >
            <Rocket size={20} className={ship.inTransit ? 'text-cyan-400' : 'text-white'} />
            <span className="text-xs text-white mt-1">{ship.name.split(' ')[1]?.slice(0, 8) || ship.name.slice(0, 8)}</span>
            <div className={`w-2 h-2 rounded-full mt-0.5 ${ship.overallEfficiency > 80 ? 'bg-green-500' : ship.overallEfficiency > 50 ? 'bg-yellow-500' : 'bg-red-500'}`} />
          </button>
        ))}
      </div>
    </div>
  );
};

// View indicator
export const ViewIndicator: React.FC = () => {
  const { currentView, showShipInterior } = useGameStore();

  if (showShipInterior) return null;

  const viewNames: Record<string, string> = {
    galaxy: 'Galaxy View',
    system: 'System View',
    planet: 'Planet View',
    ship: 'Ship View'
  };

  return (
    <div className="fixed bottom-4 right-4 bg-gray-900/80 border border-gray-700 rounded px-3 py-1.5 z-30 text-xs text-gray-400">
      {viewNames[currentView] || 'Unknown'}
    </div>
  );
};

// Main HUD
export const GameHUD: React.FC = () => {
  const { showShipInterior } = useGameStore();

  if (showShipInterior) return null;

  return (
    <>
      <TopBar />
      <SideBar />
      <ResourcePanel />
      <PlanetInfoPanel />
      <FleetMiniPanel />
      <ViewIndicator />
    </>
  );
};
