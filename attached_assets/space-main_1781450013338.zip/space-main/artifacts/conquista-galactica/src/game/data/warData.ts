// ============================================================================
// WAR DATA — Expanded roster, power score, traits, damage/armor types,
// rarity, abilities and recruitment economy.
// ============================================================================

export interface ReconTool {
  id: string;
  name: string;
  icon: string;
  cost: number;
  intelGain: number;
  stealth: number;
  desc: string;
}

export const RECON_TOOLS: ReconTool[] = [
  { id: 'probe', name: 'Sonda', icon: '🛰️', cost: 300, intelGain: 15, stealth: 0.5, desc: 'Revela estruturas básicas e recursos.' },
  { id: 'spy_sat', name: 'Satélite Espião', icon: '📡', cost: 800, intelGain: 25, stealth: 0.6, desc: 'Mapeia rotas logísticas e depósitos.' },
  { id: 'stealth_drone', name: 'Drone Furtivo', icon: '🦇', cost: 1200, intelGain: 30, stealth: 0.85, desc: 'Penetra defesas e revela hangares.' },
  { id: 'agent', name: 'Agente Infiltrado', icon: '🕵️', cost: 2000, intelGain: 40, stealth: 0.7, desc: 'Revela centros de comando e gargalos.' },
  { id: 'hacker', name: 'Hacker', icon: '💻', cost: 2600, intelGain: 50, stealth: 0.65, desc: 'Acessa redes e expõe baterias de defesa.' },
  { id: 'war_ai', name: 'IA de Guerra', icon: '🧠', cost: 4000, intelGain: 70, stealth: 0.9, desc: 'Análise total da infraestrutura inimiga.' },
];

export interface Hero {
  id: string;
  name: string;
  title: string;
  icon: string;
  ability: string;
  bonus: { type: 'logistics' | 'bombard' | 'ground' | 'repair' | 'space' | 'stealth' | 'air'; value: number };
  cost: number;
}

export const HEROES: Hero[] = [
  { id: 'h_vega', name: 'Almirante Vega', title: 'A Tempestade Orbital', icon: '⭐', ability: '+25% dano orbital', bonus: { type: 'space', value: 0.25 }, cost: 5000 },
  { id: 'h_kael', name: 'General Kael', title: 'Punho de Ferro', icon: '🎖️', ability: '+30% força terrestre', bonus: { type: 'ground', value: 0.3 }, cost: 4500 },
  { id: 'h_mira', name: 'Cientista Mira', title: 'A Engenheira', icon: '🔧', ability: 'Reparos acelerados (-40% perdas)', bonus: { type: 'repair', value: 0.4 }, cost: 4000 },
  { id: 'h_tor', name: 'Comandante Tor', title: 'O Logístico', icon: '📦', ability: '+35% saque', bonus: { type: 'logistics', value: 0.35 }, cost: 3800 },
  { id: 'h_nyx', name: 'Espectro Nyx', title: 'A Sombra', icon: '🌑', ability: 'Infiltração furtiva (+50%)', bonus: { type: 'stealth', value: 0.5 }, cost: 4200 },
  { id: 'h_drak', name: 'Lorde Drak', title: 'Devastador', icon: '☄️', ability: '+45% dano de área', bonus: { type: 'bombard', value: 0.45 }, cost: 6000 },
  { id: 'h_sera', name: 'Capitã Sera', title: 'A Asa Quebrada', icon: '🦅', ability: '+35% supremacia aérea', bonus: { type: 'air', value: 0.35 }, cost: 4600 },
];

export type DefenseStructureType =
  | 'command_center' | 'reactor' | 'shield_generator' | 'orbital_battery'
  | 'logistics_hub' | 'refinery' | 'ammo_depot' | 'comms_array'
  | 'research_center' | 'hangar' | 'flak_battery' | 'storage';

export interface DefenseStructure {
  id: string;
  type: DefenseStructureType;
  name: string;
  icon: string;
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  destroyed: boolean;
  effect: string;
}

export const DEFENSE_TYPE_INFO: Record<DefenseStructureType, { name: string; icon: string; effect: string; priority: number; armor: ArmorType }> = {
  command_center:   { name: 'Centro Administrativo Planetário', icon: '🏛️', effect: 'Comando inimigo colapsa', priority: 5, armor: 'fortified' },
  reactor:          { name: 'Reator', icon: '☢️', effect: 'Causa apagão geral', priority: 4, armor: 'heavy' },
  shield_generator: { name: 'Gerador de Escudo', icon: '🛡️', effect: 'Derruba o escudo planetário', priority: 4, armor: 'shielded' },
  orbital_battery:  { name: 'Bateria Orbital', icon: '💥', effect: 'Facilita o desembarque', priority: 5, armor: 'heavy' },
  logistics_hub:    { name: 'Centro Logístico', icon: '📦', effect: 'Interrompe abastecimento', priority: 3, armor: 'light' },
  refinery:         { name: 'Refinaria', icon: '⚗️', effect: 'Reduz produção inimiga', priority: 3, armor: 'medium' },
  ammo_depot:       { name: 'Depósito de Munição', icon: '💣', effect: 'Explosões secundárias devastadoras', priority: 3, armor: 'light' },
  comms_array:      { name: 'Centro de Comunicações', icon: '📡', effect: 'Reduz coordenação defensiva', priority: 2, armor: 'light' },
  research_center:  { name: 'Centro de Pesquisa', icon: '🔬', effect: 'Atrasa avanço tecnológico', priority: 2, armor: 'medium' },
  hangar:           { name: 'Hangar', icon: '🛩️', effect: 'Elimina reforços aéreos', priority: 2, armor: 'medium' },
  flak_battery:     { name: 'Bateria Antiaérea', icon: '🎯', effect: 'Abre o céu para drones', priority: 2, armor: 'medium' },
  storage:          { name: 'Depósito de Recursos', icon: '🏦', effect: 'Permite saque de recursos', priority: 1, armor: 'light' },
};

export type BattleLayer = 'space' | 'atmosphere' | 'landing' | 'urban';
export const BATTLE_LAYERS: BattleLayer[] = ['space', 'atmosphere', 'landing', 'urban'];

export const LAYER_INFO: Record<BattleLayer, { name: string; icon: string; desc: string; color: string }> = {
  space:      { name: 'Combate Orbital',     icon: '🌌', desc: 'Destrua satélites e baterias orbitais.', color: '#4f7cff' },
  atmosphere: { name: 'Combate Atmosférico', icon: '☁️', desc: 'Domine os céus contra caças e flak.',    color: '#82b6ff' },
  landing:    { name: 'Desembarque',         icon: '🪂', desc: 'Pouse tropas com naves de transporte.',  color: '#ff9560' },
  urban:      { name: 'Combate Urbano',      icon: '🏙️', desc: 'Capture estruturas e objetivos no solo.', color: '#ff5060' },
};

export interface WarObjective { id: string; label: string; stars: number; }
export const STAR_OBJECTIVES: WarObjective[] = [
  { id: 'destroy_command',   label: 'Destruir o Centro Administrativo Planetário', stars: 1 },
  { id: 'capture_infra',     label: 'Capturar 50% da infraestrutura',              stars: 1 },
  { id: 'cripple_production',label: 'Interromper a produção industrial',           stars: 1 },
];

// ============================================================================
// UNITS — Massively expanded with tiers, rarity, damage/armor, abilities, traits
// ============================================================================

export type DamageType  = 'kinetic' | 'energy' | 'explosive' | 'plasma' | 'emp';
export type ArmorType   = 'light' | 'medium' | 'heavy' | 'shielded' | 'fortified';
export type UnitRole    = 'assault' | 'tank' | 'support' | 'artillery' | 'scout' | 'capital' | 'special';
export type UnitRarity  = 'common' | 'rare' | 'epic' | 'legendary';
export type Visual3D    =
  | 'interceptor' | 'destroyer' | 'cruiser' | 'dreadnought'
  | 'fighter' | 'bomber' | 'gunship' | 'stealth_wing'
  | 'dropship' | 'lander' | 'orbital_paratrooper'
  | 'marine' | 'commando' | 'warbot' | 'tank' | 'mech' | 'titan' | 'artillery';

export interface UnitAbility {
  id: string;
  name: string;
  desc: string;
  /** Trigger keys consumed by the battle resolver. */
  trigger: 'volley' | 'pierce' | 'splash' | 'shield_break' | 'first_strike' | 'regen' | 'cloak' | 'siege' | 'aa' | 'overcharge';
  value: number;
}

export interface UnitType {
  id: string;
  name: string;
  icon: string;
  visual: Visual3D;
  layer: BattleLayer;
  role: UnitRole;
  rarity: UnitRarity;
  tier: 1 | 2 | 3 | 4;
  attack: number;        // raw DPS-equivalent
  hp: number;
  damageType: DamageType;
  armor: ArmorType;
  speed: number;         // 1..10
  range: number;         // 1..10
  /** Per-unit recruitment cost. */
  cost: number;
  /** Training time in seconds at standard barracks. */
  trainTime: number;
  /** Upkeep credits drained per game minute while stockpiled (small). */
  upkeep: number;
  abilities: UnitAbility[];
  desc: string;
  /** Primary accent color used by the 3D preview. */
  color: string;
}

// Helper: damage-vs-armor matrix (used by combat resolver).
export const DAMAGE_MATRIX: Record<DamageType, Record<ArmorType, number>> = {
  kinetic:   { light: 1.20, medium: 1.00, heavy: 0.70, shielded: 0.55, fortified: 0.60 },
  energy:    { light: 0.90, medium: 1.05, heavy: 1.10, shielded: 0.45, fortified: 0.80 },
  explosive: { light: 1.30, medium: 1.15, heavy: 0.95, shielded: 0.70, fortified: 1.20 },
  plasma:    { light: 1.00, medium: 1.20, heavy: 1.30, shielded: 0.85, fortified: 1.10 },
  emp:       { light: 0.50, medium: 0.60, heavy: 0.70, shielded: 1.60, fortified: 0.40 },
};

export const ASSAULT_UNITS: UnitType[] = [
  // ---------------- SPACE ----------------
  { id: 'u_interceptor', name: 'Interceptador', icon: '🚀', visual: 'interceptor', layer: 'space', role: 'scout', rarity: 'common', tier: 1,
    attack: 14, hp: 40, damageType: 'kinetic', armor: 'light', speed: 9, range: 5, cost: 400, trainTime: 8, upkeep: 0.5,
    abilities: [{ id: 'fs', name: 'Primeiro Golpe', desc: '+15% dano no primeiro turno', trigger: 'first_strike', value: 0.15 }],
    desc: 'Caça rápido de superioridade orbital. Frágil mas ataca primeiro.',
    color: '#22d3ee' },
  { id: 'u_corvette', name: 'Corveta Pulsar', icon: '🛰️', visual: 'interceptor', layer: 'space', role: 'assault', rarity: 'common', tier: 2,
    attack: 22, hp: 70, damageType: 'energy', armor: 'medium', speed: 7, range: 6, cost: 750, trainTime: 14, upkeep: 1,
    abilities: [{ id: 'sb', name: 'Quebra-Escudo', desc: '+50% dano contra escudos', trigger: 'shield_break', value: 0.5 }],
    desc: 'Especialista em abater geradores de escudo orbital.',
    color: '#38bdf8' },
  { id: 'u_destroyer', name: 'Destróier', icon: '🛸', visual: 'destroyer', layer: 'space', role: 'assault', rarity: 'rare', tier: 2,
    attack: 30, hp: 90, damageType: 'kinetic', armor: 'medium', speed: 6, range: 6, cost: 1200, trainTime: 22, upkeep: 1.5,
    abilities: [{ id: 'vol', name: 'Salva Tripla', desc: 'Dispara em 3 alvos por turno', trigger: 'volley', value: 3 }],
    desc: 'Cavalo de batalha orbital. Múltiplas torres independentes.',
    color: '#6366f1' },
  { id: 'u_cruiser', name: 'Cruzador Pesado', icon: '⚓', visual: 'cruiser', layer: 'space', role: 'tank', rarity: 'rare', tier: 3,
    attack: 55, hp: 220, damageType: 'plasma', armor: 'heavy', speed: 4, range: 7, cost: 3200, trainTime: 60, upkeep: 4,
    abilities: [{ id: 'pierce', name: 'Perfurador', desc: '30% do dano ignora armadura', trigger: 'pierce', value: 0.3 }],
    desc: 'Aríete blindado, perfura blindagens grossas com plasma.',
    color: '#8b5cf6' },
  { id: 'u_dreadnought', name: 'Dreadnought "Sol Negro"', icon: '🌑', visual: 'dreadnought', layer: 'space', role: 'capital', rarity: 'legendary', tier: 4,
    attack: 140, hp: 600, damageType: 'plasma', armor: 'fortified', speed: 2, range: 9, cost: 12000, trainTime: 240, upkeep: 18,
    abilities: [
      { id: 'sup', name: 'Canhão Solar', desc: 'Splash 40% em alvos próximos', trigger: 'splash', value: 0.4 },
      { id: 'fs', name: 'Doutrina de Salva', desc: '+20% dano de abertura', trigger: 'first_strike', value: 0.2 },
    ],
    desc: 'Nave capital lendária. Uma só vira o curso de uma batalha.',
    color: '#f59e0b' },

  // ---------------- ATMOSPHERE ----------------
  { id: 'u_fighter', name: 'Caça Atmosférico', icon: '✈️', visual: 'fighter', layer: 'atmosphere', role: 'assault', rarity: 'common', tier: 1,
    attack: 18, hp: 50, damageType: 'kinetic', armor: 'light', speed: 10, range: 4, cost: 600, trainTime: 10, upkeep: 0.7,
    abilities: [{ id: 'aa', name: 'Caça AA', desc: '+40% dano contra unidades aéreas inimigas', trigger: 'aa', value: 0.4 }],
    desc: 'Caça de superioridade aérea. Ágil em dogfights.',
    color: '#3b82f6' },
  { id: 'u_gunship', name: 'Helicóptero de Ataque', icon: '🚁', visual: 'gunship', layer: 'atmosphere', role: 'support', rarity: 'common', tier: 2,
    attack: 26, hp: 100, damageType: 'explosive', armor: 'medium', speed: 6, range: 5, cost: 1100, trainTime: 18, upkeep: 1.2,
    abilities: [{ id: 'spl', name: 'Foguetes em Salva', desc: 'Splash 25% em estruturas leves', trigger: 'splash', value: 0.25 }],
    desc: 'Apoio aéreo persistente. Devasta concentrações inimigas.',
    color: '#0ea5e9' },
  { id: 'u_bomber', name: 'Bombardeiro Pesado', icon: '🛩️', visual: 'bomber', layer: 'atmosphere', role: 'artillery', rarity: 'rare', tier: 3,
    attack: 40, hp: 60, damageType: 'explosive', armor: 'light', speed: 5, range: 8, cost: 1400, trainTime: 28, upkeep: 1.8,
    abilities: [{ id: 'siege', name: 'Carga de Demolição', desc: '+60% dano em estruturas', trigger: 'siege', value: 0.6 }],
    desc: 'Carga útil massiva. Excelente contra fortificações fixas.',
    color: '#64748b' },
  { id: 'u_stealth', name: 'Asa Fantasma', icon: '🦇', visual: 'stealth_wing', layer: 'atmosphere', role: 'special', rarity: 'epic', tier: 3,
    attack: 35, hp: 70, damageType: 'emp', armor: 'light', speed: 8, range: 6, cost: 2400, trainTime: 50, upkeep: 3,
    abilities: [
      { id: 'cloak', name: 'Camuflagem Stealth', desc: '50% chance de evitar AA inimiga', trigger: 'cloak', value: 0.5 },
      { id: 'emp', name: 'Pulso EMP', desc: 'Devasta escudos com EMP', trigger: 'shield_break', value: 0.8 },
    ],
    desc: 'Penetra defesas indetectado e desativa escudos.',
    color: '#475569' },

  // ---------------- LANDING ----------------
  { id: 'u_dropship', name: 'Nave de Desembarque', icon: '🪂', visual: 'dropship', layer: 'landing', role: 'support', rarity: 'common', tier: 1,
    attack: 6, hp: 120, damageType: 'kinetic', armor: 'medium', speed: 7, range: 2, cost: 1000, trainTime: 16, upkeep: 1,
    abilities: [{ id: 'reg', name: 'Casco Reforçado', desc: 'Recupera 5% HP por turno', trigger: 'regen', value: 0.05 }],
    desc: 'Transporta tropas e dá apoio leve durante o pouso.',
    color: '#10b981' },
  { id: 'u_lander', name: 'Cápsula de Assalto', icon: '🛰️', visual: 'lander', layer: 'landing', role: 'assault', rarity: 'rare', tier: 2,
    attack: 18, hp: 90, damageType: 'explosive', armor: 'medium', speed: 9, range: 1, cost: 1400, trainTime: 22, upkeep: 1.4,
    abilities: [{ id: 'fs', name: 'Aterrissagem Cinética', desc: '+40% dano no impacto inicial', trigger: 'first_strike', value: 0.4 }],
    desc: 'Cai do céu como meteoro e abre brechas defensivas.',
    color: '#f97316' },
  { id: 'u_paratrooper', name: 'Paraquedista Orbital', icon: '🪖', visual: 'orbital_paratrooper', layer: 'landing', role: 'scout', rarity: 'rare', tier: 2,
    attack: 22, hp: 75, damageType: 'kinetic', armor: 'light', speed: 8, range: 3, cost: 1100, trainTime: 18, upkeep: 1.1,
    abilities: [{ id: 'cloak', name: 'Inserção Furtiva', desc: '40% chance de ignorar primeira salva inimiga', trigger: 'cloak', value: 0.4 }],
    desc: 'Tropas de elite lançadas direto da órbita.',
    color: '#84cc16' },

  // ---------------- URBAN ----------------
  { id: 'u_marine', name: 'Tropa de Choque', icon: '🪖', visual: 'marine', layer: 'urban', role: 'assault', rarity: 'common', tier: 1,
    attack: 16, hp: 35, damageType: 'kinetic', armor: 'light', speed: 6, range: 3, cost: 300, trainTime: 6, upkeep: 0.3,
    abilities: [],
    desc: 'Infantaria padrão. Barata, abundante e versátil.',
    color: '#dc2626' },
  { id: 'u_commando', name: 'Comando de Elite', icon: '🥷', visual: 'commando', layer: 'urban', role: 'special', rarity: 'epic', tier: 3,
    attack: 38, hp: 75, damageType: 'explosive', armor: 'medium', speed: 8, range: 4, cost: 1800, trainTime: 36, upkeep: 2.4,
    abilities: [
      { id: 'fs', name: 'Emboscada', desc: '+50% dano na primeira troca', trigger: 'first_strike', value: 0.5 },
      { id: 'pierce', name: 'Sabotador', desc: '25% do dano ignora armadura', trigger: 'pierce', value: 0.25 },
    ],
    desc: 'Operadores de elite. Caros mas mortais.',
    color: '#a855f7' },
  { id: 'u_warbot', name: 'Robô de Guerra', icon: '🤖', visual: 'warbot', layer: 'urban', role: 'assault', rarity: 'rare', tier: 2,
    attack: 28, hp: 70, damageType: 'energy', armor: 'medium', speed: 5, range: 4, cost: 800, trainTime: 16, upkeep: 1,
    abilities: [{ id: 'reg', name: 'Auto-reparo', desc: 'Recupera 3% HP por turno', trigger: 'regen', value: 0.03 }],
    desc: 'Bípede de combate autônomo. Confiável em qualquer cenário.',
    color: '#06b6d4' },
  { id: 'u_tank', name: 'Tanque de Assalto', icon: '🛻', visual: 'tank', layer: 'urban', role: 'tank', rarity: 'rare', tier: 2,
    attack: 36, hp: 180, damageType: 'kinetic', armor: 'heavy', speed: 3, range: 5, cost: 1500, trainTime: 30, upkeep: 2,
    abilities: [{ id: 'pierce', name: 'Munição APFSDS', desc: '40% perfurante', trigger: 'pierce', value: 0.4 }],
    desc: 'Tanque pesado. Anula tropas leves no contato.',
    color: '#7c2d12' },
  { id: 'u_mech', name: 'Mech "Golias"', icon: '🦾', visual: 'mech', layer: 'urban', role: 'tank', rarity: 'epic', tier: 3,
    attack: 55, hp: 280, damageType: 'plasma', armor: 'heavy', speed: 4, range: 5, cost: 3000, trainTime: 60, upkeep: 4,
    abilities: [
      { id: 'spl', name: 'Mini-Splash', desc: 'Splash 20%', trigger: 'splash', value: 0.2 },
      { id: 'siege', name: 'Demolidor', desc: '+30% contra fortificações', trigger: 'siege', value: 0.3 },
    ],
    desc: 'Bípede pesado com canhão de plasma e blindagem reativa.',
    color: '#facc15' },
  { id: 'u_artillery', name: 'Artilharia Long Tom', icon: '💥', visual: 'artillery', layer: 'urban', role: 'artillery', rarity: 'rare', tier: 3,
    attack: 70, hp: 95, damageType: 'explosive', armor: 'light', speed: 2, range: 10, cost: 2400, trainTime: 45, upkeep: 2.5,
    abilities: [
      { id: 'spl', name: 'Tiro de Saturação', desc: 'Splash 50%', trigger: 'splash', value: 0.5 },
      { id: 'siege', name: 'Devastação', desc: '+50% dano em estruturas', trigger: 'siege', value: 0.5 },
    ],
    desc: 'Artilharia de longo alcance. Devasta defesas sem entrar no fogo.',
    color: '#b45309' },
  { id: 'u_titan', name: 'Titã "Ragnarok"', icon: '⚙️', visual: 'titan', layer: 'urban', role: 'capital', rarity: 'legendary', tier: 4,
    attack: 160, hp: 800, damageType: 'plasma', armor: 'fortified', speed: 2, range: 7, cost: 14000, trainTime: 300, upkeep: 22,
    abilities: [
      { id: 'spl', name: 'Pisada Sísmica', desc: 'Splash 60%', trigger: 'splash', value: 0.6 },
      { id: 'siege', name: 'Aniquilador', desc: '+80% dano em estruturas', trigger: 'siege', value: 0.8 },
      { id: 'reg', name: 'Nanomáquinas', desc: 'Regenera 4% HP/turno', trigger: 'regen', value: 0.04 },
    ],
    desc: 'Caminhão de guerra colossal. A definição de superioridade.',
    color: '#ef4444' },
];

export const UNIT_BY_ID: Record<string, UnitType> = Object.fromEntries(ASSAULT_UNITS.map(u => [u.id, u]));

// ============================================================================
// POWER SCORE — single comparable metric (offensive + defensive + utility)
// ============================================================================
export function computeUnitPower(u: UnitType): number {
  const offensive = u.attack * (1 + u.range * 0.04);
  const defensive = u.hp * 0.35;
  const mobility  = u.speed * 1.6;
  const abilityScore = u.abilities.reduce((sum, a) => {
    switch (a.trigger) {
      case 'volley':       return sum + a.value * 8;
      case 'pierce':       return sum + a.value * 30;
      case 'splash':       return sum + a.value * 40;
      case 'shield_break': return sum + a.value * 20;
      case 'first_strike': return sum + a.value * 25;
      case 'regen':        return sum + a.value * 200;
      case 'cloak':        return sum + a.value * 20;
      case 'siege':        return sum + a.value * 30;
      case 'aa':           return sum + a.value * 18;
      case 'overcharge':   return sum + a.value * 25;
      default:             return sum;
    }
  }, 0);
  const armorBonus = ({ light: 0, medium: 8, heavy: 18, shielded: 22, fortified: 30 } as Record<ArmorType, number>)[u.armor];
  const rarityMult = ({ common: 1.0, rare: 1.05, epic: 1.12, legendary: 1.22 } as Record<UnitRarity, number>)[u.rarity];
  return Math.round((offensive + defensive + mobility + abilityScore + armorBonus) * rarityMult);
}

export function computeArmyPower(stacks: { unitId: string; count: number }[]): number {
  return stacks.reduce((sum, s) => {
    const u = UNIT_BY_ID[s.unitId];
    if (!u) return sum;
    return sum + computeUnitPower(u) * s.count;
  }, 0);
}

export const RARITY_INFO: Record<UnitRarity, { label: string; color: string; ring: string; glow: string }> = {
  common:    { label: 'Comum',     color: 'text-slate-300', ring: 'ring-slate-500/40',    glow: 'shadow-slate-500/20' },
  rare:      { label: 'Raro',      color: 'text-sky-300',   ring: 'ring-sky-400/50',      glow: 'shadow-sky-500/30' },
  epic:      { label: 'Épico',     color: 'text-fuchsia-300', ring: 'ring-fuchsia-400/50', glow: 'shadow-fuchsia-500/40' },
  legendary: { label: 'Lendário',  color: 'text-amber-300', ring: 'ring-amber-400/60',    glow: 'shadow-amber-500/40' },
};

export const ROLE_INFO: Record<UnitRole, { label: string; icon: string }> = {
  assault:   { label: 'Assalto',    icon: '⚔️' },
  tank:      { label: 'Tanque',     icon: '🛡️' },
  support:   { label: 'Apoio',      icon: '🩹' },
  artillery: { label: 'Artilharia', icon: '💥' },
  scout:     { label: 'Batedor',    icon: '👁️' },
  capital:   { label: 'Capital',    icon: '👑' },
  special:   { label: 'Especial',   icon: '✨' },
};

export const DAMAGE_INFO: Record<DamageType, { label: string; color: string }> = {
  kinetic:   { label: 'Cinético',  color: '#94a3b8' },
  energy:    { label: 'Energia',   color: '#22d3ee' },
  explosive: { label: 'Explosivo', color: '#f97316' },
  plasma:    { label: 'Plasma',    color: '#a855f7' },
  emp:       { label: 'EMP',       color: '#facc15' },
};

export const ARMOR_INFO: Record<ArmorType, { label: string; color: string }> = {
  light:     { label: 'Leve',       color: '#cbd5e1' },
  medium:    { label: 'Média',      color: '#94a3b8' },
  heavy:     { label: 'Pesada',     color: '#64748b' },
  shielded:  { label: 'Escudada',   color: '#22d3ee' },
  fortified: { label: 'Fortificada', color: '#f59e0b' },
};
